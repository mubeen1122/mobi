import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertUserSchema, insertTruckSchema, insertShiftSchema, 
  insertAttendanceSchema, insertNotificationSchema, insertWorkplaceLocationSchema,
  insertNotificationPreferencesSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication endpoints
  app.post("/api/login", async (req: Request, res: Response) => {
    try {
      const { username, password } = req.body;
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // Don't send password back to client
      const { password: _, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Server error during login" });
    }
  });
  
  app.post("/api/register", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(userData);
      
      // Don't send password back to client
      const { password: _, ...userWithoutPassword } = user;
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error during registration" });
    }
  });
  
  // Current user endpoint - used by the auth hook
  app.get("/api/user", async (req: Request, res: Response) => {
    try {
      // Get logged in user from session (when we implement sessions)
      // For now, returning 401 because we're using local authentication
      res.status(401).json({ message: "Not authenticated" });
    } catch (error) {
      res.status(500).json({ message: "Server error" });
    }
  });
  
  // User endpoints
  app.get("/api/users", async (_req: Request, res: Response) => {
    try {
      // In a real production app, we would implement pagination here
      const allUsers = [];
      
      // Fetch users one by one since we don't have a getAllUsers method
      // This is just a workaround - in real app we would have proper getAllUsers method
      // Try to get users with IDs 1-10 to capture most users
      for (let i = 1; i <= 10; i++) {
        const user = await storage.getUser(i);
        if (user) {
          // Don't send password back to client
          const { password: _, ...userWithoutPassword } = user;
          allUsers.push(userWithoutPassword);
        }
      }
      
      res.json(allUsers);
    } catch (error) {
      console.error("Error fetching all users:", error);
      res.status(500).json({ message: "Error fetching users" });
    }
  });

  app.get("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't send password back to client
      const { password: _, ...userWithoutPassword } = user;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      res.status(500).json({ message: "Server error retrieving user" });
    }
  });
  
  app.patch("/api/users/:id", async (req: Request, res: Response) => {
    try {
      console.log("Updating user. Request body:", req.body);
      
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const userData = req.body;
      
      // Validate the user exists before attempting update
      const existingUser = await storage.getUser(userId);
      if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      console.log(`Updating user ${userId} with data:`, userData);
      
      const updatedUser = await storage.updateUser(userId, userData);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      console.log("User updated:", updatedUser);
      
      // Don't send password back to client
      const { password: _, ...userWithoutPassword } = updatedUser;
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error("Error updating user:", error);
      res.status(500).json({ 
        message: "Server error updating user",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Truck endpoints
  app.get("/api/trucks", async (_req: Request, res: Response) => {
    try {
      const trucks = await storage.getTrucks();
      res.status(200).json(trucks);
    } catch (error) {
      res.status(500).json({ message: "Server error retrieving trucks" });
    }
  });
  
  app.get("/api/trucks/:id", async (req: Request, res: Response) => {
    try {
      const truckId = parseInt(req.params.id);
      const truck = await storage.getTruck(truckId);
      
      if (!truck) {
        return res.status(404).json({ message: "Truck not found" });
      }
      
      res.status(200).json(truck);
    } catch (error) {
      res.status(500).json({ message: "Server error retrieving truck" });
    }
  });
  
  app.post("/api/trucks", async (req: Request, res: Response) => {
    try {
      const truckData = insertTruckSchema.parse(req.body);
      
      const existingTruck = await storage.getTruckByNumber(truckData.truckNumber);
      if (existingTruck) {
        return res.status(400).json({ message: "Truck number already exists" });
      }
      
      const truck = await storage.createTruck(truckData);
      res.status(201).json(truck);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid truck data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error creating truck" });
    }
  });
  
  app.patch("/api/trucks/:id", async (req: Request, res: Response) => {
    try {
      const truckId = parseInt(req.params.id);
      const truckData = req.body;
      
      const updatedTruck = await storage.updateTruck(truckId, truckData);
      if (!updatedTruck) {
        return res.status(404).json({ message: "Truck not found" });
      }
      
      res.status(200).json(updatedTruck);
    } catch (error) {
      res.status(500).json({ message: "Server error updating truck" });
    }
  });
  
  // Shift endpoints
  app.get("/api/shifts", async (_req: Request, res: Response) => {
    try {
      const shifts = await storage.getShifts();
      res.status(200).json(shifts);
    } catch (error) {
      res.status(500).json({ message: "Server error retrieving shifts" });
    }
  });
  
  app.get("/api/shifts/driver/:driverId", async (req: Request, res: Response) => {
    try {
      const driverId = parseInt(req.params.driverId);
      const shifts = await storage.getShiftsByDriver(driverId);
      res.status(200).json(shifts);
    } catch (error) {
      res.status(500).json({ message: "Server error retrieving driver shifts" });
    }
  });
  
  app.post("/api/shifts", async (req: Request, res: Response) => {
    try {
      const shiftData = insertShiftSchema.parse(req.body);
      const shift = await storage.createShift(shiftData);
      res.status(201).json(shift);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid shift data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error creating shift" });
    }
  });
  
  app.patch("/api/shifts/:id", async (req: Request, res: Response) => {
    try {
      const shiftId = parseInt(req.params.id);
      const shiftData = req.body;
      
      const updatedShift = await storage.updateShift(shiftId, shiftData);
      if (!updatedShift) {
        return res.status(404).json({ message: "Shift not found" });
      }
      
      res.status(200).json(updatedShift);
    } catch (error) {
      res.status(500).json({ message: "Server error updating shift" });
    }
  });
  
  // Attendance endpoints
  app.get("/api/attendance/user/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const attendance = await storage.getAttendanceByUser(userId);
      res.status(200).json(attendance);
    } catch (error) {
      res.status(500).json({ message: "Server error retrieving attendance" });
    }
  });
  
  app.get("/api/attendance/date/:date", async (req: Request, res: Response) => {
    try {
      const date = req.params.date;
      const attendance = await storage.getAttendanceByDate(date);
      res.status(200).json(attendance);
    } catch (error) {
      res.status(500).json({ message: "Server error retrieving attendance by date" });
    }
  });
  
  app.post("/api/attendance", async (req: Request, res: Response) => {
    try {
      console.log("Received attendance data:", req.body);
      
      // Try to parse the data with the schema
      const attendanceData = insertAttendanceSchema.parse(req.body);
      console.log("Parsed attendance data:", attendanceData);
      
      // Create the attendance record
      const attendance = await storage.createAttendance(attendanceData);
      console.log("Created attendance record:", attendance);
      
      res.status(201).json(attendance);
    } catch (error) {
      console.error("Error creating attendance:", error);
      
      if (error instanceof z.ZodError) {
        console.error("Zod validation error:", error.errors);
        return res.status(400).json({ 
          message: "Invalid attendance data", 
          errors: error.errors,
          received: req.body
        });
      }
      
      res.status(500).json({ 
        message: "Server error creating attendance",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  app.patch("/api/attendance/:id", async (req: Request, res: Response) => {
    try {
      const attendanceId = parseInt(req.params.id);
      const attendanceData = req.body;
      
      console.log("Updating attendance record. Request body:", attendanceData);
      
      // Handle date transformation if endTime is provided as a string
      if (attendanceData.endTime && typeof attendanceData.endTime === 'string') {
        attendanceData.endTime = new Date(attendanceData.endTime);
      }
      
      console.log("Transformed attendance data:", attendanceData);
      
      const updatedAttendance = await storage.updateAttendance(attendanceId, attendanceData);
      if (!updatedAttendance) {
        return res.status(404).json({ message: "Attendance record not found" });
      }
      
      console.log("Updated attendance record:", updatedAttendance);
      res.status(200).json(updatedAttendance);
    } catch (error) {
      console.error("Error updating attendance:", error);
      
      if (error instanceof z.ZodError) {
        console.error("Zod validation error:", error.errors);
        return res.status(400).json({ 
          message: "Invalid attendance data", 
          errors: error.errors,
          received: req.body
        });
      }
      
      res.status(500).json({ 
        message: "Server error updating attendance",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Notification endpoints
  app.get("/api/notifications/user/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const notifications = await storage.getNotificationsByUser(userId);
      res.status(200).json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Server error retrieving notifications" });
    }
  });
  
  app.post("/api/notifications", async (req: Request, res: Response) => {
    try {
      const notificationData = insertNotificationSchema.parse(req.body);
      const notification = await storage.createNotification(notificationData);
      res.status(201).json(notification);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid notification data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error creating notification" });
    }
  });
  
  app.patch("/api/notifications/:id", async (req: Request, res: Response) => {
    try {
      const notificationId = parseInt(req.params.id);
      const notificationData = req.body;
      
      const updatedNotification = await storage.updateNotification(notificationId, notificationData);
      if (!updatedNotification) {
        return res.status(404).json({ message: "Notification not found" });
      }
      
      res.status(200).json(updatedNotification);
    } catch (error) {
      res.status(500).json({ message: "Server error updating notification" });
    }
  });

  // Workplace Location API for geofencing
  app.get("/api/workplace-locations", async (_req: Request, res: Response) => {
    try {
      const locations = await storage.getWorkplaceLocations();
      res.status(200).json(locations);
    } catch (error) {
      res.status(500).json({ message: "Server error retrieving workplace locations" });
    }
  });
  
  app.get("/api/workplace-locations/active", async (_req: Request, res: Response) => {
    try {
      const location = await storage.getActiveWorkplaceLocation();
      if (!location) {
        return res.status(404).json({ message: "No active workplace location found" });
      }
      res.status(200).json(location);
    } catch (error) {
      res.status(500).json({ message: "Server error retrieving active workplace location" });
    }
  });
  
  app.get("/api/workplace-locations/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid location ID" });
      }
      
      const location = await storage.getWorkplaceLocation(id);
      if (!location) {
        return res.status(404).json({ message: "Workplace location not found" });
      }
      res.status(200).json(location);
    } catch (error) {
      res.status(500).json({ message: "Server error retrieving workplace location" });
    }
  });
  
  app.post("/api/workplace-locations", async (req: Request, res: Response) => {
    try {
      const locationData = insertWorkplaceLocationSchema.parse(req.body);
      const location = await storage.createWorkplaceLocation(locationData);
      res.status(201).json(location);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid location data", errors: error.errors });
      }
      res.status(500).json({ message: "Server error creating workplace location" });
    }
  });
  
  app.patch("/api/workplace-locations/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid location ID" });
      }
      
      const locationData = req.body;
      const updatedLocation = await storage.updateWorkplaceLocation(id, locationData);
      if (!updatedLocation) {
        return res.status(404).json({ message: "Workplace location not found" });
      }
      res.status(200).json(updatedLocation);
    } catch (error) {
      res.status(500).json({ message: "Server error updating workplace location" });
    }
  });
  
  app.delete("/api/workplace-locations/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid location ID" });
      }
      
      const success = await storage.deleteWorkplaceLocation(id);
      if (!success) {
        return res.status(404).json({ message: "Workplace location not found" });
      }
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Server error deleting workplace location" });
    }
  });

  // Notification preferences endpoints
  app.get("/api/notification-preferences/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID format" });
      }
      
      const preferences = await storage.getNotificationPreferences(userId);
      if (!preferences) {
        // If no preferences found, return default values
        return res.status(200).json({
          userId,
          shiftReminders: true,
          scheduleUpdates: true,
          absenceAlerts: true,
          pushNotifications: true,
          emailNotifications: false,
          updatedAt: new Date()
        });
      }
      
      res.status(200).json(preferences);
    } catch (error) {
      console.error("Error getting notification preferences:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.post("/api/notification-preferences", async (req: Request, res: Response) => {
    try {
      const insertPreferences = insertNotificationPreferencesSchema.parse(req.body);
      
      // Check if preferences already exist for this user
      const existingPreferences = await storage.getNotificationPreferences(insertPreferences.userId);
      if (existingPreferences) {
        // If preferences exist, update them instead
        const updatedPreferences = await storage.updateNotificationPreferences(
          insertPreferences.userId, 
          insertPreferences
        );
        return res.status(200).json(updatedPreferences);
      }
      
      const preferences = await storage.createNotificationPreferences(insertPreferences);
      res.status(201).json(preferences);
    } catch (error) {
      console.error("Error creating notification preferences:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid notification preferences data",
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.patch("/api/notification-preferences/:userId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID format" });
      }
      
      // Partially validate the update fields
      const updateData = req.body;
      
      // Check if preferences exist
      const existingPreferences = await storage.getNotificationPreferences(userId);
      if (!existingPreferences) {
        // If no preferences exist, create them with default values plus the updates
        const newPreferences = await storage.createNotificationPreferences({
          userId,
          shiftReminders: updateData.shiftReminders !== undefined ? updateData.shiftReminders : false,
          scheduleUpdates: updateData.scheduleUpdates !== undefined ? updateData.scheduleUpdates : false,
          absenceAlerts: updateData.absenceAlerts !== undefined ? updateData.absenceAlerts : false,
          pushNotifications: updateData.pushNotifications !== undefined ? updateData.pushNotifications : false,
          emailNotifications: updateData.emailNotifications !== undefined ? updateData.emailNotifications : false,
          updatedAt: new Date()
        });
        return res.status(201).json(newPreferences);
      }
      
      // Update preferences
      const updatedPreferences = await storage.updateNotificationPreferences(userId, updateData);
      if (!updatedPreferences) {
        return res.status(404).json({ message: "Notification preferences not found" });
      }
      
      res.status(200).json(updatedPreferences);
    } catch (error) {
      console.error("Error updating notification preferences:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid notification preferences data",
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
