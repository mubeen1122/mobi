import { 
  users, type User, type InsertUser, 
  trucks, type Truck, type InsertTruck, 
  shifts, type Shift, type InsertShift, 
  attendance, type Attendance, type InsertAttendance, 
  notifications, type Notification, type InsertNotification,
  workplaceLocations, type WorkplaceLocation, type InsertWorkplaceLocation,
  notificationPreferences, type NotificationPreferences, type InsertNotificationPreferences
} from "@shared/schema";
import session from "express-session";
import { db, pool } from "./db";
import { eq, and } from "drizzle-orm";
import connectPgSimple from "connect-pg-simple";

export interface IStorage {
  sessionStore: session.Store;
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  
  // Truck operations
  getTruck(id: number): Promise<Truck | undefined>;
  getTruckByNumber(truckNumber: string): Promise<Truck | undefined>;
  getTrucks(): Promise<Truck[]>;
  createTruck(truck: InsertTruck): Promise<Truck>;
  updateTruck(id: number, truck: Partial<InsertTruck>): Promise<Truck | undefined>;
  
  // Shift operations
  getShift(id: number): Promise<Shift | undefined>;
  getShifts(): Promise<Shift[]>;
  getShiftsByDriver(driverId: number): Promise<Shift[]>;
  createShift(shift: InsertShift): Promise<Shift>;
  updateShift(id: number, shift: Partial<InsertShift>): Promise<Shift | undefined>;
  
  // Attendance operations
  getAttendance(id: number): Promise<Attendance | undefined>;
  getAttendanceByUser(userId: number): Promise<Attendance[]>;
  getAttendanceByDate(date: string): Promise<Attendance[]>;
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: number, attendance: Partial<InsertAttendance>): Promise<Attendance | undefined>;
  
  // Notification operations
  getNotification(id: number): Promise<Notification | undefined>;
  getNotificationsByUser(userId: number): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  updateNotification(id: number, notification: Partial<InsertNotification>): Promise<Notification | undefined>;
  
  // Notification Preferences operations
  getNotificationPreferences(userId: number): Promise<NotificationPreferences | undefined>;
  createNotificationPreferences(preferences: InsertNotificationPreferences): Promise<NotificationPreferences>;
  updateNotificationPreferences(userId: number, preferences: Partial<InsertNotificationPreferences>): Promise<NotificationPreferences | undefined>;
  
  // Workplace Location operations for geofencing
  getWorkplaceLocation(id: number): Promise<WorkplaceLocation | undefined>;
  getWorkplaceLocations(): Promise<WorkplaceLocation[]>;
  getActiveWorkplaceLocation(): Promise<WorkplaceLocation | undefined>;
  createWorkplaceLocation(location: InsertWorkplaceLocation): Promise<WorkplaceLocation>;
  updateWorkplaceLocation(id: number, location: Partial<InsertWorkplaceLocation>): Promise<WorkplaceLocation | undefined>;
  deleteWorkplaceLocation(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  sessionStore: session.Store;
  private users: Map<number, User>;
  private trucks: Map<number, Truck>;
  private shifts: Map<number, Shift>;
  private attendances: Map<number, Attendance>;
  private notifications: Map<number, Notification>;
  private workplaceLocations: Map<number, WorkplaceLocation>;
  private notificationPreferences: Map<number, NotificationPreferences>;
  
  private currentUserId: number;
  private currentTruckId: number;
  private currentShiftId: number;
  private currentAttendanceId: number;
  private currentNotificationId: number;
  private currentWorkplaceLocationId: number;
  private currentNotificationPreferencesId: number;

  constructor() {
    // Create memory session store
    const MemoryStore = require('memorystore')(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    this.users = new Map();
    this.trucks = new Map();
    this.shifts = new Map();
    this.attendances = new Map();
    this.notifications = new Map();
    this.workplaceLocations = new Map();
    this.notificationPreferences = new Map();
    
    this.currentUserId = 1;
    this.currentTruckId = 1;
    this.currentShiftId = 1;
    this.currentAttendanceId = 1;
    this.currentNotificationId = 1;
    this.currentWorkplaceLocationId = 1;
    this.currentNotificationPreferencesId = 1;
    
    // Create initial admin user
    this.createUser({
      username: "admin",
      password: "admin123",
      name: "Admin User",
      role: "admin",
      email: "admin@ogrsystem.com"
    });
    
    // Create initial driver user
    this.createUser({
      username: "driver",
      password: "driver123",
      name: "John Doe",
      role: "driver",
      email: "driver@ogrsystem.com"
    });
    
    // Create initial trucks
    this.createTruck({
      truckNumber: "T-1234",
      status: "Active",
      assignedTo: 2
    });
    
    this.createTruck({
      truckNumber: "T-5678",
      status: "Active"
    });
    
    this.createTruck({
      truckNumber: "T-9101",
      status: "In Repair"
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Truck operations
  async getTruck(id: number): Promise<Truck | undefined> {
    return this.trucks.get(id);
  }
  
  async getTruckByNumber(truckNumber: string): Promise<Truck | undefined> {
    return Array.from(this.trucks.values()).find(
      (truck) => truck.truckNumber === truckNumber
    );
  }
  
  async getTrucks(): Promise<Truck[]> {
    return Array.from(this.trucks.values());
  }
  
  async createTruck(insertTruck: InsertTruck): Promise<Truck> {
    const id = this.currentTruckId++;
    const truck: Truck = { ...insertTruck, id };
    this.trucks.set(id, truck);
    return truck;
  }
  
  async updateTruck(id: number, truckData: Partial<InsertTruck>): Promise<Truck | undefined> {
    const truck = this.trucks.get(id);
    if (!truck) return undefined;
    
    const updatedTruck = { ...truck, ...truckData };
    this.trucks.set(id, updatedTruck);
    return updatedTruck;
  }
  
  // Shift operations
  async getShift(id: number): Promise<Shift | undefined> {
    return this.shifts.get(id);
  }
  
  async getShifts(): Promise<Shift[]> {
    return Array.from(this.shifts.values());
  }
  
  async getShiftsByDriver(driverId: number): Promise<Shift[]> {
    return Array.from(this.shifts.values()).filter(
      (shift) => shift.assignedDriver === driverId
    );
  }
  
  async createShift(insertShift: InsertShift): Promise<Shift> {
    const id = this.currentShiftId++;
    const shift: Shift = { ...insertShift, id };
    this.shifts.set(id, shift);
    return shift;
  }
  
  async updateShift(id: number, shiftData: Partial<InsertShift>): Promise<Shift | undefined> {
    const shift = this.shifts.get(id);
    if (!shift) return undefined;
    
    const updatedShift = { ...shift, ...shiftData };
    this.shifts.set(id, updatedShift);
    return updatedShift;
  }
  
  // Attendance operations
  async getAttendance(id: number): Promise<Attendance | undefined> {
    return this.attendances.get(id);
  }
  
  async getAttendanceByUser(userId: number): Promise<Attendance[]> {
    return Array.from(this.attendances.values()).filter(
      (attendance) => attendance.userId === userId
    );
  }
  
  async getAttendanceByDate(date: string): Promise<Attendance[]> {
    return Array.from(this.attendances.values()).filter(
      (attendance) => attendance.date === date
    );
  }
  
  async createAttendance(insertAttendance: InsertAttendance): Promise<Attendance> {
    const id = this.currentAttendanceId++;
    const attendance: Attendance = { ...insertAttendance, id };
    this.attendances.set(id, attendance);
    return attendance;
  }
  
  async updateAttendance(id: number, attendanceData: Partial<InsertAttendance>): Promise<Attendance | undefined> {
    const attendance = this.attendances.get(id);
    if (!attendance) return undefined;
    
    const updatedAttendance = { ...attendance, ...attendanceData };
    this.attendances.set(id, updatedAttendance);
    return updatedAttendance;
  }
  
  // Notification operations
  async getNotification(id: number): Promise<Notification | undefined> {
    return this.notifications.get(id);
  }
  
  async getNotificationsByUser(userId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values()).filter(
      (notification) => notification.sentTo === userId
    );
  }
  
  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = this.currentNotificationId++;
    const notification: Notification = { ...insertNotification, id };
    this.notifications.set(id, notification);
    return notification;
  }
  
  async updateNotification(id: number, notificationData: Partial<InsertNotification>): Promise<Notification | undefined> {
    const notification = this.notifications.get(id);
    if (!notification) return undefined;
    
    const updatedNotification = { ...notification, ...notificationData };
    this.notifications.set(id, updatedNotification);
    return updatedNotification;
  }
  
  // Workplace Location operations for geofencing
  async getWorkplaceLocation(id: number): Promise<WorkplaceLocation | undefined> {
    return this.workplaceLocations.get(id);
  }

  async getWorkplaceLocations(): Promise<WorkplaceLocation[]> {
    return Array.from(this.workplaceLocations.values());
  }

  async getActiveWorkplaceLocation(): Promise<WorkplaceLocation | undefined> {
    return Array.from(this.workplaceLocations.values()).find(
      (location) => location.isActive === true
    );
  }

  async createWorkplaceLocation(insertLocation: InsertWorkplaceLocation): Promise<WorkplaceLocation> {
    // If this is set as active, deactivate all other locations
    if (insertLocation.isActive) {
      for (const [id, location] of this.workplaceLocations.entries()) {
        if (location.isActive) {
          this.workplaceLocations.set(id, { ...location, isActive: false });
        }
      }
    }
    
    const id = this.currentWorkplaceLocationId++;
    const location: WorkplaceLocation = { 
      ...insertLocation, 
      id,
      createdAt: new Date()
    };
    this.workplaceLocations.set(id, location);
    return location;
  }

  async updateWorkplaceLocation(id: number, locationData: Partial<InsertWorkplaceLocation>): Promise<WorkplaceLocation | undefined> {
    const location = this.workplaceLocations.get(id);
    if (!location) return undefined;
    
    // If this is set as active, deactivate all other locations
    if (locationData.isActive) {
      for (const [locId, loc] of this.workplaceLocations.entries()) {
        if (loc.isActive && locId !== id) {
          this.workplaceLocations.set(locId, { ...loc, isActive: false });
        }
      }
    }
    
    const updatedLocation = { ...location, ...locationData };
    this.workplaceLocations.set(id, updatedLocation);
    return updatedLocation;
  }

  async deleteWorkplaceLocation(id: number): Promise<boolean> {
    return this.workplaceLocations.delete(id);
  }
  
  // Notification Preferences operations
  async getNotificationPreferences(userId: number): Promise<NotificationPreferences | undefined> {
    return Array.from(this.notificationPreferences.values()).find(
      (prefs) => prefs.userId === userId
    );
  }
  
  async createNotificationPreferences(insertPreferences: InsertNotificationPreferences): Promise<NotificationPreferences> {
    const id = this.currentNotificationPreferencesId++;
    const preferences: NotificationPreferences = { 
      ...insertPreferences, 
      id,
      updatedAt: new Date()
    };
    this.notificationPreferences.set(id, preferences);
    return preferences;
  }
  
  async updateNotificationPreferences(userId: number, preferencesData: Partial<InsertNotificationPreferences>): Promise<NotificationPreferences | undefined> {
    const preferences = Array.from(this.notificationPreferences.values()).find(
      (prefs) => prefs.userId === userId
    );
    if (!preferences) return undefined;
    
    const updatedPreferences = { 
      ...preferences, 
      ...preferencesData,
      updatedAt: new Date()
    };
    this.notificationPreferences.set(preferences.id, updatedPreferences);
    return updatedPreferences;
  }
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    const PgSessionStore = connectPgSimple(session);
    this.sessionStore = new PgSessionStore({
      pool,
      createTableIfMissing: true
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [result] = await db.insert(users).values(user).returning();
    return result;
  }
  
  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const [result] = await db.update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return result;
  }
  
  // Truck operations
  async getTruck(id: number): Promise<Truck | undefined> {
    const [truck] = await db.select().from(trucks).where(eq(trucks.id, id));
    return truck;
  }
  
  async getTruckByNumber(truckNumber: string): Promise<Truck | undefined> {
    const [truck] = await db.select().from(trucks).where(eq(trucks.truckNumber, truckNumber));
    return truck;
  }
  
  async getTrucks(): Promise<Truck[]> {
    return await db.select().from(trucks);
  }
  
  async createTruck(truck: InsertTruck): Promise<Truck> {
    const [result] = await db.insert(trucks).values(truck).returning();
    return result;
  }
  
  async updateTruck(id: number, truckData: Partial<InsertTruck>): Promise<Truck | undefined> {
    const [result] = await db.update(trucks)
      .set(truckData)
      .where(eq(trucks.id, id))
      .returning();
    return result;
  }
  
  // Shift operations
  async getShift(id: number): Promise<Shift | undefined> {
    const [shift] = await db.select().from(shifts).where(eq(shifts.id, id));
    return shift;
  }
  
  async getShifts(): Promise<Shift[]> {
    return await db.select().from(shifts);
  }
  
  async getShiftsByDriver(driverId: number): Promise<Shift[]> {
    return await db.select().from(shifts).where(eq(shifts.assignedDriver, driverId));
  }
  
  async createShift(shift: InsertShift): Promise<Shift> {
    const [result] = await db.insert(shifts).values(shift).returning();
    return result;
  }
  
  async updateShift(id: number, shiftData: Partial<InsertShift>): Promise<Shift | undefined> {
    const [result] = await db.update(shifts)
      .set(shiftData)
      .where(eq(shifts.id, id))
      .returning();
    return result;
  }
  
  // Attendance operations
  async getAttendance(id: number): Promise<Attendance | undefined> {
    const [record] = await db.select().from(attendance).where(eq(attendance.id, id));
    return record;
  }
  
  async getAttendanceByUser(userId: number): Promise<Attendance[]> {
    return await db.select().from(attendance).where(eq(attendance.userId, userId));
  }
  
  async getAttendanceByDate(date: string): Promise<Attendance[]> {
    return await db.select().from(attendance).where(eq(attendance.date, date));
  }
  
  async createAttendance(record: InsertAttendance): Promise<Attendance> {
    const [result] = await db.insert(attendance).values(record).returning();
    return result;
  }
  
  async updateAttendance(id: number, attendanceData: Partial<InsertAttendance>): Promise<Attendance | undefined> {
    const [result] = await db.update(attendance)
      .set(attendanceData)
      .where(eq(attendance.id, id))
      .returning();
    return result;
  }
  
  // Notification operations
  async getNotification(id: number): Promise<Notification | undefined> {
    const [notification] = await db.select().from(notifications).where(eq(notifications.id, id));
    return notification;
  }
  
  async getNotificationsByUser(userId: number): Promise<Notification[]> {
    return await db.select().from(notifications).where(eq(notifications.sentTo, userId));
  }
  
  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [result] = await db.insert(notifications).values(notification).returning();
    return result;
  }
  
  async updateNotification(id: number, notificationData: Partial<InsertNotification>): Promise<Notification | undefined> {
    const [result] = await db.update(notifications)
      .set(notificationData)
      .where(eq(notifications.id, id))
      .returning();
    return result;
  }

  // Workplace Location operations for geofencing
  async getWorkplaceLocation(id: number): Promise<WorkplaceLocation | undefined> {
    const [location] = await db.select().from(workplaceLocations).where(eq(workplaceLocations.id, id));
    return location;
  }

  async getWorkplaceLocations(): Promise<WorkplaceLocation[]> {
    return await db.select().from(workplaceLocations);
  }

  async getActiveWorkplaceLocation(): Promise<WorkplaceLocation | undefined> {
    const [location] = await db.select().from(workplaceLocations).where(eq(workplaceLocations.isActive, true));
    return location;
  }

  async createWorkplaceLocation(location: InsertWorkplaceLocation): Promise<WorkplaceLocation> {
    // If this is set as active, deactivate all other locations
    if (location.isActive) {
      await db.update(workplaceLocations)
        .set({ isActive: false })
        .where(eq(workplaceLocations.isActive, true));
    }
    
    const [result] = await db.insert(workplaceLocations).values(location).returning();
    return result;
  }

  async updateWorkplaceLocation(id: number, locationData: Partial<InsertWorkplaceLocation>): Promise<WorkplaceLocation | undefined> {
    // If this is set as active, deactivate all other locations
    if (locationData.isActive) {
      await db.update(workplaceLocations)
        .set({ isActive: false })
        .where(eq(workplaceLocations.isActive, true));
    }
    
    const [result] = await db.update(workplaceLocations)
      .set(locationData)
      .where(eq(workplaceLocations.id, id))
      .returning();
    return result;
  }

  async deleteWorkplaceLocation(id: number): Promise<boolean> {
    const [result] = await db.delete(workplaceLocations)
      .where(eq(workplaceLocations.id, id))
      .returning();
    return !!result;
  }
  
  // Notification Preferences operations
  async getNotificationPreferences(userId: number): Promise<NotificationPreferences | undefined> {
    const [preferences] = await db.select()
      .from(notificationPreferences)
      .where(eq(notificationPreferences.userId, userId));
    return preferences;
  }
  
  async createNotificationPreferences(preferences: InsertNotificationPreferences): Promise<NotificationPreferences> {
    const [result] = await db.insert(notificationPreferences)
      .values({
        ...preferences,
        updatedAt: new Date()
      })
      .returning();
    return result;
  }
  
  async updateNotificationPreferences(userId: number, preferencesData: Partial<InsertNotificationPreferences>): Promise<NotificationPreferences | undefined> {
    const [result] = await db.update(notificationPreferences)
      .set({
        ...preferencesData,
        updatedAt: new Date()
      })
      .where(eq(notificationPreferences.userId, userId))
      .returning();
    return result;
  }
}

// Initialize the database by creating seed data if needed
async function initializeDatabase() {
  // Check if we have any users
  const existingUsers = await db.select().from(users);
  
  if (existingUsers.length === 0) {
    // Create admin user
    await db.insert(users).values({
      username: "admin",
      password: "admin123",
      name: "Admin User",
      role: "admin",
      email: "admin@fleettrack.com"
    });
    
    // Create driver user
    await db.insert(users).values({
      username: "driver",
      password: "driver123",
      name: "John Doe",
      role: "driver",
      email: "driver@fleettrack.com"
    });
    
    // Create some trucks
    await db.insert(trucks).values([
      {
        truckNumber: "T-1234",
        status: "Active",
        assignedTo: 2
      },
      {
        truckNumber: "T-5678",
        status: "Active"
      },
      {
        truckNumber: "T-9101",
        status: "In Repair"
      }
    ]);
  }
}

// Initialize database and create the storage instance
initializeDatabase().catch(console.error);
export const storage = new DatabaseStorage();
