// Keys for localStorage
const KEYS = {
  USER: 'ogrsystem-user',
  TRUCKS: 'ogrsystem-trucks',
  SHIFTS: 'ogrsystem-shifts',
  ATTENDANCE: 'ogrsystem-attendance',
  NOTIFICATIONS: 'ogrsystem-notifications',
};

// Generic get function with type safety
export function getItem<T>(key: string): T | null {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : null;
  } catch (error) {
    console.error(`Error retrieving ${key} from localStorage:`, error);
    return null;
  }
}

// Generic set function
export function setItem<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Error storing ${key} in localStorage:`, error);
  }
}

// Generic remove function
export function removeItem(key: string): void {
  try {
    localStorage.removeItem(key);
  } catch (error) {
    console.error(`Error removing ${key} from localStorage:`, error);
  }
}

// User-specific functions
export function getCurrentUser() {
  return getItem(KEYS.USER);
}

export function setCurrentUser(user: any) {
  setItem(KEYS.USER, user);
}

export function clearCurrentUser() {
  removeItem(KEYS.USER);
}

// Check if the app is being used for the first time
export function isFirstTimeUse(): boolean {
  const hasUsedBefore = localStorage.getItem('ogrsystem-initialized');
  if (!hasUsedBefore) {
    localStorage.setItem('ogrsystem-initialized', 'true');
    return true;
  }
  return false;
}

// Initialize localStorage with default data if first time
export function initializeLocalStorageIfNeeded() {
  if (isFirstTimeUse()) {
    // Initialize with empty arrays
    setItem(KEYS.TRUCKS, []);
    setItem(KEYS.SHIFTS, []);
    setItem(KEYS.ATTENDANCE, []);
    setItem(KEYS.NOTIFICATIONS, []);
  }
}
