import { useMemo } from "react";
import { type Shift } from "@shared/schema";
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  isToday,
  getDay,
} from "date-fns";
import { Skeleton } from "@/components/ui/skeleton";

interface CalendarViewProps {
  currentMonth: Date;
  shifts: Shift[];
  loading?: boolean;
}

export default function CalendarView({
  currentMonth,
  shifts,
  loading = false,
}: CalendarViewProps) {
  // Generate calendar days for the current month
  const calendarDays = useMemo(() => {
    const start = startOfMonth(currentMonth);
    const end = endOfMonth(currentMonth);
    const days = eachDayOfInterval({ start, end });

    // Add days from previous month to fill first week
    const firstDayOfMonth = getDay(start);
    const prevMonthDays = Array.from({ length: firstDayOfMonth }, (_, i) => {
      const day = new Date(start);
      day.setDate(1 - (firstDayOfMonth - i));
      return day;
    });

    // Add days from next month to complete grid
    const lastDayOfMonth = getDay(end);
    const nextMonthDays = Array.from(
      { length: 6 - lastDayOfMonth },
      (_, i) => {
        const day = new Date(end);
        day.setDate(end.getDate() + i + 1);
        return day;
      }
    );

    return [...prevMonthDays, ...days, ...nextMonthDays];
  }, [currentMonth]);

  // Get shifts for a specific day
  const getShiftsForDay = (day: Date) => {
    return shifts.filter((shift) => {
      const shiftDate = new Date(shift.shiftDate);
      return isSameDay(shiftDate, day);
    });
  };

  // Get status color for shifts
  const getShiftStatusColor = (shifts: Shift[]) => {
    if (shifts.length === 0) return null;

    if (shifts.some((shift) => shift.shiftStatus === "Completed")) {
      return "bg-green-500";
    }
    if (shifts.some((shift) => shift.shiftStatus === "Accepted")) {
      return "bg-primary";
    }
    if (shifts.some((shift) => shift.shiftStatus === "Scheduled")) {
      return "bg-yellow-500";
    }
    return null;
  };

  if (loading) {
    return (
      <div className="space-y-2">
        <div className="grid grid-cols-7 gap-2 mb-2">
          {Array.from({ length: 7 }).map((_, i) => (
            <div key={i} className="text-center text-sm text-gray-500">
              {format(new Date(2023, 0, i + 1), "EEE").substring(0, 2)}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-2">
          {Array.from({ length: 35 }).map((_, i) => (
            <Skeleton
              key={i}
              className="aspect-square w-full rounded-md"
            />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-7 gap-2 mb-2">
        {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((day) => (
          <div key={day} className="text-center text-sm text-gray-500">
            {day}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-2">
        {calendarDays.map((day, index) => {
          const dayShifts = getShiftsForDay(day);
          const shiftColor = getShiftStatusColor(dayShifts);

          return (
            <div
              key={index}
              className={`aspect-square border rounded-md flex flex-col items-center justify-center relative hover:bg-gray-50 cursor-pointer ${
                !isSameMonth(day, currentMonth)
                  ? "text-gray-300 bg-gray-50"
                  : ""
              } ${isToday(day) ? "bg-primary-50 border-primary" : ""}`}
            >
              <span
                className={`text-sm ${
                  isToday(day) ? "font-medium text-primary" : ""
                }`}
              >
                {format(day, "d")}
              </span>
              {shiftColor && (
                <span
                  className={`absolute bottom-1 w-2 h-2 rounded-full ${shiftColor}`}
                />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
