import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import {
  LayoutDashboard,
  Users,
  CalendarDays,
  Truck,
  ClipboardList,
  LogOut,
  Menu,
  User,
  Settings,
  Calendar,
  ClipboardCheck,
  MapPin
} from "lucide-react";

interface AdminLayoutProps {
  children: React.ReactNode;
}

export default function AdminLayout({ children }: AdminLayoutProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [isSheetOpen, setIsSheetOpen] = useState(false);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const getInitials = (name: string | undefined) => {
    if (!name) return "??";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("");
  };

  const navigationItems = [
    {
      path: "/admin",
      label: "Dashboard",
      icon: <LayoutDashboard className="h-5 w-5" />,
    },
    {
      path: "/admin/workers",
      label: "Workers",
      icon: <Users className="h-5 w-5" />,
    },
    {
      path: "/admin/shifts",
      label: "Shifts",
      icon: <CalendarDays className="h-5 w-5" />,
    },
    {
      path: "/admin/duty-assignment",
      label: "Duty Assignment",
      icon: <ClipboardCheck className="h-5 w-5" />,
    },
    {
      path: "/admin/trucks",
      label: "Trucks",
      icon: <Truck className="h-5 w-5" />,
    },
    {
      path: "/admin/attendance",
      label: "Attendance",
      icon: <ClipboardList className="h-5 w-5" />,
    },
    {
      path: "/admin/locations",
      label: "Locations",
      icon: <MapPin className="h-5 w-5" />,
    },
  ];

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-gray-100">
      {/* Mobile Header */}
      <header className="bg-white shadow-sm md:hidden p-4 flex items-center justify-between">
        <div className="flex items-center">
          <h1 className="text-xl font-bold text-green-500">Ogr System</h1>
          <p className="text-xs text-gray-500 ml-2">Admin</p>
        </div>
        <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="md:hidden">
              <Menu className="h-6 w-6" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[250px] sm:w-[300px]">
            <div className="flex flex-col h-full">
              <div className="p-4 border-b border-gray-200">
                <h1 className="text-xl font-bold text-green-500">Ogr System</h1>
                <p className="text-xs text-gray-500">Admin Panel</p>
              </div>
              <div className="flex-1 py-4">
                <nav className="space-y-1">
                  {navigationItems.map((item) => (
                    <Link
                      key={item.path}
                      href={item.path}
                      onClick={() => setIsSheetOpen(false)}
                      className={`flex items-center px-3 py-3 rounded-md ${
                        location === item.path
                          ? "bg-green-500 text-white"
                          : "text-gray-700 hover:bg-gray-100"
                      }`}
                    >
                      {item.icon}
                      <span className="ml-3">{item.label}</span>
                    </Link>
                  ))}
                </nav>
              </div>
              <div className="border-t border-gray-200 py-4">
                <button
                  onClick={handleLogout}
                  className="flex w-full items-center px-3 py-3 text-gray-700 hover:bg-gray-100 rounded-md"
                >
                  <LogOut className="h-5 w-5" />
                  <span className="ml-3">Logout</span>
                </button>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </header>

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex bg-gray-800 text-white w-64 flex-shrink-0 flex-col">
        <div className="p-4 border-b border-gray-700">
          <h1 className="text-xl font-bold text-green-500">Ogr System</h1>
          <p className="text-xs text-gray-400">Admin Panel</p>
        </div>

        <nav className="p-4 flex-1">
          {navigationItems.map((item) => (
            <Link 
              key={item.path} 
              href={item.path}
              className={`flex items-center px-4 py-3 mb-2 rounded-md ${
                location === item.path
                  ? "bg-green-700 text-white"
                  : "text-gray-300 hover:bg-green-600 hover:text-white"
              }`}
            >
              {item.icon}
              <span className="ml-3">{item.label}</span>
            </Link>
          ))}
        </nav>

        <div className="mt-auto p-4 border-t border-gray-700">
          <Link 
            href="/admin"
            className="flex items-center p-2"
          >
            <Avatar className="h-8 w-8 mr-2 bg-green-500 text-white">
              <AvatarFallback>{getInitials(user?.name)}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-sm font-medium">{user?.name || "Admin"}</p>
              <p className="text-xs text-gray-400">{user?.role || "admin"}</p>
            </div>
          </Link>
          <button
            onClick={handleLogout}
            className="flex items-center px-4 py-2 mt-2 w-full rounded-md text-gray-300 hover:bg-green-600 hover:text-white"
          >
            <LogOut className="h-4 w-4 mr-3" />
            Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">{children}</main>
    </div>
  );
}
