import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Home, CalendarDays, Clock, User, LogOut, Menu, Bell } from "lucide-react";

interface DriverLayoutProps {
  children: React.ReactNode;
}

export default function DriverLayout({ children }: DriverLayoutProps) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [isSheetOpen, setIsSheetOpen] = useState(false);

  const getInitials = (name: string | undefined) => {
    if (!name) return "??";
    return name
      .split(" ")
      .map((n) => n[0])
      .join("");
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const navigationItems = [
    { path: "/", label: "Home", icon: <Home className="h-5 w-5" /> },
    {
      path: "/schedule",
      label: "Schedule",
      icon: <CalendarDays className="h-5 w-5" />,
    },
    { path: "/duty", label: "Duty", icon: <Clock className="h-5 w-5" /> },
    { path: "/profile", label: "Profile", icon: <User className="h-5 w-5" /> },
    { path: "/notifications", label: "Notifications", icon: <Bell className="h-5 w-5" /> },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-gray-50">
      {/* Mobile Header */}
      <header className="bg-white shadow-sm md:hidden">
        <div className="px-4 py-4 flex items-center justify-between">
          <div className="flex items-center">
            <Avatar className="h-10 w-10 bg-green-500 text-white">
              <AvatarFallback>{getInitials(user?.name)}</AvatarFallback>
            </Avatar>
            <div className="ml-3">
              <h1 className="text-lg font-semibold">{user?.name || "Driver"}</h1>
              <p className="text-sm text-gray-600">{user?.role || "Driver"}</p>
            </div>
          </div>
          <Sheet open={isSheetOpen} onOpenChange={setIsSheetOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[250px] sm:w-[300px]">
              <div className="flex flex-col h-full">
                <div className="flex-1 py-4">
                  <div className="mb-6 flex items-center">
                    <Avatar className="h-10 w-10 bg-green-500 text-white">
                      <AvatarFallback>
                        {getInitials(user?.name)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="ml-3">
                      <h3 className="font-medium">{user?.name || "Driver"}</h3>
                      <p className="text-sm text-gray-500">{user?.role || "Driver"}</p>
                    </div>
                  </div>
                  <nav className="space-y-1">
                    {navigationItems.map((item) => (
                      <Link
                        key={item.path}
                        href={item.path}
                        onClick={() => setIsSheetOpen(false)}
                        className={`flex items-center px-3 py-3 rounded-md ${
                          location === item.path
                            ? "bg-green-500 text-white"
                            : "text-gray-700 hover:bg-green-50"
                        }`}
                      >
                        {item.icon}
                        <span className="ml-3">{item.label}</span>
                      </Link>
                    ))}
                  </nav>
                </div>
                <div className="border-t border-gray-200 py-4">
                  <button
                    onClick={handleLogout}
                    className="flex w-full items-center px-3 py-3 text-gray-700 hover:bg-green-50 rounded-md"
                  >
                    <LogOut className="h-5 w-5" />
                    <span className="ml-3">Logout</span>
                  </button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      {/* Desktop Header */}
      <header className="bg-white shadow-sm hidden md:block">
        <div className="px-6 py-4 flex items-center justify-between">
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-green-500">Ogr System</h1>
            <nav className="ml-10 flex items-center space-x-6">
              {navigationItems.map((item) => (
                <Link 
                  key={item.path} 
                  href={item.path}
                  className={`flex items-center px-1 py-1 ${
                    location === item.path
                      ? "text-green-500 border-b-2 border-green-500"
                      : "text-gray-700 hover:text-green-500"
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                <Avatar className="h-10 w-10 bg-green-500 text-white">
                  <AvatarFallback>{getInitials(user?.name)}</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <div className="flex items-center justify-start gap-2 p-2">
                <div className="flex flex-col space-y-0.5 leading-none">
                  <p className="font-medium text-sm">{user?.name || "Driver"}</p>
                  <p className="text-xs text-gray-500">{user?.role || "Driver"}</p>
                </div>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link 
                  href="/profile"
                  className="cursor-pointer w-full flex items-center"
                >
                  <User className="h-4 w-4 mr-2" />
                  <span>Profile</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link 
                  href="/notifications"
                  className="cursor-pointer w-full flex items-center"
                >
                  <Bell className="h-4 w-4 mr-2" />
                  <span>Notification Settings</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                className="cursor-pointer"
                onClick={handleLogout}
              >
                <LogOut className="h-4 w-4 mr-2" />
                <span>Logout</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">{children}</main>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden bg-white border-t border-gray-200 flex items-center justify-around px-2 pt-2 pb-6">
        {navigationItems.map((item) => (
          <Link 
            key={item.path} 
            href={item.path}
            className={`flex flex-col items-center p-2 ${
              location === item.path
                ? "text-green-500"
                : "text-gray-600"
            }`}
          >
            {item.icon}
            <span className="text-xs mt-1">{item.label}</span>
          </Link>
        ))}
      </nav>
    </div>
  );
}
