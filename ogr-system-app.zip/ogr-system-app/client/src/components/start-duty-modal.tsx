import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, MapPin, CheckCircle, AlertTriangle, HelpCircle } from "lucide-react";
import TruckSelector from "@/components/truck-selector";
import { format } from "date-fns";
import { useGeolocation } from "@/hooks/use-geolocation";

interface StartDutyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDutyStart: () => void;
  isAtWorkplace: boolean;
}

export default function StartDutyModal({
  isOpen,
  onClose,
  onDutyStart,
  isAtWorkplace,
}: StartDutyModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedTruck, setSelectedTruck] = useState("");
  const [isStarting, setIsStarting] = useState(false);
  const { error: geoError, getPosition } = useGeolocation();
  const [retryingLocation, setRetryingLocation] = useState(false);

  const handleStartDuty = async () => {
    if (!user) {
      toast({
        title: "Error",
        description: "You must be logged in to start a duty",
        variant: "destructive",
      });
      return;
    }

    if (!selectedTruck) {
      toast({
        title: "Truck required",
        description: "Please select a truck to start your duty",
        variant: "destructive",
      });
      return;
    }

    if (!isAtWorkplace) {
      toast({
        title: "Location verification failed",
        description: "You must be at the workplace to start a duty",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsStarting(true);
      
      // Start the duty by creating an attendance record
      const response = await apiRequest("POST", "/api/attendance", {
        userId: user.id,
        startTime: new Date().toISOString(), // Send as ISO string for Zod transformation
        endTime: null,  // explicitly set endTime as null
        status: "Present",
        vehicleNumber: selectedTruck,
        date: format(new Date(), 'yyyy-MM-dd')
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        console.log("Error response from server:", errorData);
        
        // Create a more detailed error message
        let errorMessage = errorData.message || "Failed to start duty";
        
        if (errorData.errors) {
          errorMessage += ": " + JSON.stringify(errorData.errors);
        }
        
        throw new Error(errorMessage);
      }

      // Update user's assigned truck
      const userResponse = await apiRequest("PATCH", `/api/users/${user.id}`, {
        assignedTruck: selectedTruck
      });
      
      if (!userResponse.ok) {
        const errorData = await userResponse.json();
        throw new Error(errorData.message || "Failed to update assigned truck");
      }

      toast({
        title: "Duty started",
        description: `Your duty has been started with truck ${selectedTruck}`,
      });

      onDutyStart();
      onClose();
    } catch (error) {
      console.error("Error starting duty:", error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to start duty. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsStarting(false);
    }
  };

  const handleRetryLocation = async () => {
    setRetryingLocation(true);
    await getPosition();
    setRetryingLocation(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Start Duty</DialogTitle>
          <DialogDescription>
            Select your truck and verify your location to start your duty
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 space-y-4">
          <TruckSelector
            selectedTruck={selectedTruck}
            onChange={setSelectedTruck}
            disabled={isStarting}
          />

          <div>
            <p className="text-sm text-gray-600 mb-2">
              Your current location will be verified before starting duty.
            </p>
            
            {/* Location status box */}
            <div className="flex items-center justify-between px-4 py-3 bg-blue-50 rounded-md">
              <div className="flex items-center">
                <MapPin className="h-5 w-5 text-primary mr-2" />
                <span className="text-sm font-medium">Location Verification</span>
              </div>

              {isAtWorkplace ? (
                <div className="flex items-center text-green-600">
                  <CheckCircle className="h-4 w-4 mr-1" />
                  <span className="text-sm">Verified</span>
                </div>
              ) : (
                <div className="flex items-center text-amber-600">
                  <AlertTriangle className="h-4 w-4 mr-1" />
                  <span className="text-sm">Not at workplace</span>
                </div>
              )}
            </div>
            
            {/* Location error help box */}
            {geoError && !isAtWorkplace && (
              <div className="mt-3 p-3 bg-amber-50 border border-amber-200 rounded-md">
                <div className="flex items-start">
                  <HelpCircle className="h-5 w-5 text-amber-600 mr-2 flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-sm font-medium text-amber-800">Location Permission Issue</h4>
                    <p className="text-xs text-amber-800 mt-1">{geoError}</p>
                    
                    <div className="mt-2 text-xs text-amber-700">
                      <p className="mb-1 font-medium">Mobile Device Instructions:</p>
                      <ol className="list-decimal pl-5 space-y-1">
                        <li>Check that location is enabled in your device settings</li>
                        <li>Allow location permission for this website when prompted</li>
                        <li>Try using a different browser if the problem persists</li>
                        <li>Make sure you are physically at the workplace location</li>
                      </ol>
                    </div>
                    
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="mt-2 w-full bg-white" 
                      onClick={handleRetryLocation}
                      disabled={retryingLocation}
                    >
                      {retryingLocation ? (
                        <>
                          <Loader2 className="mr-1 h-3 w-3 animate-spin" />
                          Checking Location...
                        </>
                      ) : (
                        "Try Again"
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        <DialogFooter className="flex justify-end space-x-2">
          <Button
            variant="outline"
            onClick={onClose}
            disabled={isStarting}
          >
            Cancel
          </Button>
          <Button
            onClick={handleStartDuty}
            disabled={!selectedTruck || !isAtWorkplace || isStarting}
          >
            {isStarting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Starting Duty...
              </>
            ) : (
              "Start Duty"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
