import { useState, useEffect } from "react";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { type Truck } from "@shared/schema";

interface TruckSelectorProps {
  selectedTruck: string;
  onChange: (truckNumber: string) => void;
  disabled?: boolean;
}

export default function TruckSelector({
  selectedTruck,
  onChange,
  disabled = false,
}: TruckSelectorProps) {
  // Fetch all active trucks
  const { data: trucks, isLoading } = useQuery<Truck[]>({
    queryKey: ["/api/trucks"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/trucks");
      return await res.json();
    },
  });

  // Filter only active trucks
  const activeTrucks = trucks?.filter(
    (truck) => truck.status === "Active"
  ) || [];

  if (isLoading) {
    return (
      <div className="space-y-2">
        <Label>Select Truck</Label>
        <Skeleton className="h-10 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <Label htmlFor="truckSelector">Select Truck</Label>
      <Select
        value={selectedTruck}
        onValueChange={onChange}
        disabled={disabled}
      >
        <SelectTrigger id="truckSelector">
          <SelectValue placeholder="-- Select Truck --" />
        </SelectTrigger>
        <SelectContent>
          {activeTrucks.length === 0 ? (
            <SelectItem value="none" disabled>
              No trucks available
            </SelectItem>
          ) : (
            <>
              {activeTrucks.map((truck) => (
                <SelectItem key={truck.id} value={truck.truckNumber}>
                  {truck.truckNumber}
                </SelectItem>
              ))}
            </>
          )}
        </SelectContent>
      </Select>
    </div>
  );
}
