import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { format, differenceInMinutes } from "date-fns";
import { Loader2 } from "lucide-react";

interface DutyCardProps {
  activeDuty: any | null;
  onDutyEnd: () => void;
}

export default function DutyCard({ activeDuty, onDutyEnd }: DutyCardProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isEnding, setIsEnding] = useState(false);
  const [elapsedTime, setElapsedTime] = useState("0h 0m");

  // Update elapsed time if active duty
  useEffect(() => {
    if (!activeDuty) return;

    const calculateElapsedTime = () => {
      const startTime = new Date(activeDuty.startTime);
      const now = new Date();
      const diffInMinutes = differenceInMinutes(now, startTime);
      const hours = Math.floor(diffInMinutes / 60);
      const minutes = diffInMinutes % 60;
      setElapsedTime(`${hours}h ${minutes}m`);
    };

    calculateElapsedTime();
    const interval = setInterval(calculateElapsedTime, 60000); // Update every minute

    return () => clearInterval(interval);
  }, [activeDuty]);

  // Handle duty end
  const handleEndDuty = async () => {
    if (!activeDuty || !user) return;

    try {
      setIsEnding(true);
      const response = await apiRequest("PATCH", `/api/attendance/${activeDuty.id}`, {
        endTime: new Date().toISOString(),
        status: "Completed" // Add status to ensure we have all required fields
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        console.log("Error response from server:", errorData);
        
        let errorMessage = errorData.message || "Failed to end duty";
        
        if (errorData.errors) {
          errorMessage += ": " + JSON.stringify(errorData.errors);
        }
        
        throw new Error(errorMessage);
      }

      toast({
        title: "Duty ended",
        description: "Your duty has been successfully ended.",
      });

      onDutyEnd();
    } catch (error) {
      console.error("Error ending duty:", error);
      toast({
        title: "Error",
        description: error instanceof Error 
          ? error.message 
          : "Failed to end duty. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsEnding(false);
    }
  };

  if (!activeDuty) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Current Duty</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="py-6 text-center text-gray-500">
            <p>No active duty</p>
            <p className="text-sm mt-1">
              Start a duty to begin tracking your work hours
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Current Duty</CardTitle>
          <Badge className="bg-green-500 text-white">On Duty</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <span className="block text-sm text-gray-500">Truck Number</span>
            <span className="block font-medium">
              {activeDuty.vehicleNumber || "Not specified"}
            </span>
          </div>
          <div>
            <span className="block text-sm text-gray-500">Start Time</span>
            <span className="block font-medium">
              {format(new Date(activeDuty.startTime), "h:mm a")}
            </span>
          </div>
          <div>
            <span className="block text-sm text-gray-500">Elapsed Time</span>
            <span className="block font-medium">{elapsedTime}</span>
          </div>
          <div>
            <span className="block text-sm text-gray-500">Status</span>
            <span className="block font-medium text-green-600">Active</span>
          </div>
        </div>

        <Button
          variant="destructive"
          className="w-full"
          onClick={handleEndDuty}
          disabled={isEnding}
        >
          {isEnding ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Ending Duty...
            </>
          ) : (
            "End Duty"
          )}
        </Button>
      </CardContent>
    </Card>
  );
}
