import { useEffect, useState } from 'react';
import { checkAllDrivers } from '@/services/attendance-checker';
import { queryClient } from '@/lib/queryClient';
import { format } from 'date-fns';

// Interval to run the checker (30 minutes)
const CHECK_INTERVAL_MS = 30 * 60 * 1000;

/**
 * Component that runs in the background to periodically check for absent drivers
 * based on their scheduled shifts. This component doesn't render anything visually.
 */
export default function AutomaticAbsenceChecker() {
  const [lastCheckTime, setLastCheckTime] = useState<Date | null>(null);
  
  useEffect(() => {
    // Run the check immediately when the component mounts
    const initialCheck = async () => {
      try {
        const today = format(new Date(), 'yyyy-MM-dd');
        
        // Run the check
        const absentCount = await checkAllDrivers();
        
        // Log check result
        console.log(`[Automatic absence check] Ran check at ${new Date().toLocaleTimeString()}, ${absentCount} drivers marked absent`);
        
        // Update the state to record when we last ran the check
        setLastCheckTime(new Date());
        
        // Refresh data
        queryClient.invalidateQueries({ queryKey: ['/api/attendance/date', today] });
      } catch (error) {
        console.error('Error running automatic absence check:', error);
      }
    };
    
    initialCheck();
    
    // Set up recurring check
    const intervalId = setInterval(async () => {
      await initialCheck();
    }, CHECK_INTERVAL_MS);
    
    return () => {
      clearInterval(intervalId);
    };
  }, []);
  
  // This component doesn't render anything visually
  return null;
}