import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "next-themes";
import { AuthProvider } from "@/hooks/use-auth";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import DriverDashboard from "@/pages/driver-dashboard";
import DriverSchedule from "@/pages/driver-schedule";
import DriverDuty from "@/pages/driver-duty";
import DriverProfile from "@/pages/driver-profile";
import NotificationSettings from "@/pages/notification-settings";
import AdminDashboard from "@/pages/admin-dashboard";
import AdminWorkers from "@/pages/admin-workers";
import AdminShifts from "@/pages/admin-shifts";
import AdminTrucks from "@/pages/admin-trucks";
import AdminAttendance from "@/pages/admin-attendance";
import AdminDutyAssignment from "@/pages/admin-duty-assignment";
import AdminLocations from "@/pages/admin-locations";
import { ProtectedRoute } from "@/lib/protected-route";
import { useEffect } from "react";
import { initializeLocalStorageIfNeeded } from "@/lib/local-storage";
import AutomaticAbsenceChecker from "@/components/automatic-absence-checker";

function Router() {
  return (
    <Switch>
      {/* Auth route */}
      <Route path="/auth" component={AuthPage} />
      
      {/* Driver routes */}
      <ProtectedRoute path="/" component={DriverDashboard} />
      <ProtectedRoute path="/schedule" component={DriverSchedule} />
      <ProtectedRoute path="/duty" component={DriverDuty} />
      <ProtectedRoute path="/profile" component={DriverProfile} />
      <ProtectedRoute path="/notifications" component={NotificationSettings} />
      
      {/* Admin routes */}
      <ProtectedRoute path="/admin" component={AdminDashboard} adminOnly={true} />
      <ProtectedRoute path="/admin/workers" component={AdminWorkers} adminOnly={true} />
      <ProtectedRoute path="/admin/shifts" component={AdminShifts} adminOnly={true} />
      <ProtectedRoute path="/admin/trucks" component={AdminTrucks} adminOnly={true} />
      <ProtectedRoute path="/admin/attendance" component={AdminAttendance} adminOnly={true} />
      <ProtectedRoute path="/admin/duty-assignment" component={AdminDutyAssignment} adminOnly={true} />
      <ProtectedRoute path="/admin/locations" component={AdminLocations} adminOnly={true} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  useEffect(() => {
    // Initialize localStorage with default data if first time
    initializeLocalStorageIfNeeded();
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="light">
        <AuthProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
            {/* Background checker that runs periodically to mark absent drivers */}
            <AutomaticAbsenceChecker />
          </TooltipProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
