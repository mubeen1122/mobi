import { useState, useEffect } from "react";

interface GeolocationState {
  position: {
    latitude: number | null;
    longitude: number | null;
    accuracy: number | null;
  };
  error: string | null;
  loading: boolean;
}

interface GeolocationResult extends GeolocationState {
  getPosition: () => Promise<GeolocationCoordinates | null>;
  isAtWorkLocation: (workLat: number, workLng: number, radiusInMeters: number) => boolean;
  distanceToWork: (workLat: number, workLng: number) => number | null;
}

export function useGeolocation(): GeolocationResult {
  const [state, setState] = useState<GeolocationState>({
    position: {
      latitude: null,
      longitude: null,
      accuracy: null,
    },
    error: null,
    loading: true,
  });

  // Calculate distance between two points using Haversine formula (in meters)
  const calculateDistance = (
    lat1: number,
    lon1: number,
    lat2: number,
    lon2: number
  ): number => {
    const R = 6371e3; // Earth radius in meters
    const φ1 = (lat1 * Math.PI) / 180;
    const φ2 = (lat2 * Math.PI) / 180;
    const Δφ = ((lat2 - lat1) * Math.PI) / 180;
    const Δλ = ((lon2 - lon1) * Math.PI) / 180;

    const a =
      Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
      Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
  };

  // Check if user is at work location within given radius
  const isAtWorkLocation = (
    workLat: number,
    workLng: number,
    radiusInMeters: number
  ): boolean => {
    const { latitude, longitude } = state.position;
    
    if (latitude === null || longitude === null) {
      return false;
    }
    
    const distance = calculateDistance(latitude, longitude, workLat, workLng);
    return distance <= radiusInMeters;
  };

  // Get distance to work location
  const distanceToWork = (workLat: number, workLng: number): number | null => {
    const { latitude, longitude } = state.position;
    
    if (latitude === null || longitude === null) {
      return null;
    }
    
    return calculateDistance(latitude, longitude, workLat, workLng);
  };

  // Get current position as a Promise
  const getPosition = (): Promise<GeolocationCoordinates | null> => {
    setState((prev) => ({ ...prev, loading: true, error: null }));
    
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        setState((prev) => ({
          ...prev,
          loading: false,
          error: "Geolocation is not supported by your browser",
        }));
        resolve(null);
        return;
      }

      // Use a timeout to handle scenarios where the permission dialog gets blocked or ignored
      const timeoutId = setTimeout(() => {
        setState((prev) => ({
          ...prev,
          loading: false,
          error: "Location request timed out. Please check your location settings and permissions.",
        }));
        resolve(null);
      }, 20000); // 20 seconds timeout
      
      try {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            clearTimeout(timeoutId);
            setState({
              position: {
                latitude: position.coords.latitude,
                longitude: position.coords.longitude,
                accuracy: position.coords.accuracy,
              },
              loading: false,
              error: null,
            });
            resolve(position.coords);
          },
          (error) => {
            clearTimeout(timeoutId);
            console.error("Geolocation error:", error);
            
            // More user-friendly error messages based on error code
            let errorMessage = "Unable to get your location.";
            
            switch (error.code) {
              case 1: // PERMISSION_DENIED
                errorMessage = "Location permission denied. Please enable location services for this site in your browser settings.";
                break;
              case 2: // POSITION_UNAVAILABLE
                errorMessage = "Your current location is unavailable. Please try again in a different area.";
                break;
              case 3: // TIMEOUT
                errorMessage = "Location request timed out. Please check your connection and try again.";
                break;
            }
            
            setState((prev) => ({
              ...prev,
              loading: false,
              error: errorMessage,
            }));
            resolve(null);
          },
          { 
            enableHighAccuracy: true, 
            timeout: 15000, 
            maximumAge: 0 
          }
        );
      } catch (e) {
        clearTimeout(timeoutId);
        console.error("Unexpected geolocation error:", e);
        setState((prev) => ({
          ...prev,
          loading: false,
          error: "Unexpected error getting your location. Please try again."
        }));
        resolve(null);
      }
    });
  };

  // Initialize geolocation on mount
  useEffect(() => {
    getPosition();
  }, []);

  return {
    ...state,
    getPosition,
    isAtWorkLocation,
    distanceToWork,
  };
}
