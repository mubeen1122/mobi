import { format, parseISO, differenceInMinutes } from 'date-fns';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { type Shift, type User } from '@shared/schema';
import { toast } from '@/hooks/use-toast';

// Time window in minutes after which a driver is considered absent
export const LATE_THRESHOLD_MINUTES = 15;

/**
 * Checks if a driver should be marked as absent based on their scheduled shift
 * @param shift The shift to check
 */
export async function checkAndMarkAbsent(shift: Shift): Promise<boolean> {
  try {
    if (!shift.assignedDriver || shift.shiftStatus !== 'Scheduled') {
      return false;
    }

    // Parse the shift start time
    const shiftDate = shift.shiftDate;
    const startTimeStr = shift.startTime;
    
    // Combine date and time to create a Date object
    const [hours, minutes] = startTimeStr.split(':').map(Number);
    const shiftStartDate = new Date(shiftDate);
    shiftStartDate.setHours(hours, minutes, 0, 0);
    
    const now = new Date();
    
    // Only process shifts in the past up to the late threshold
    const minutesDiff = differenceInMinutes(now, shiftStartDate);
    
    if (minutesDiff < 0 || minutesDiff > 24 * 60) {
      // If shift is in the future or was more than 24 hours ago, don't process
      return false;
    }

    if (minutesDiff >= LATE_THRESHOLD_MINUTES) {
      // Check if driver already has attendance for this day
      const formattedDate = format(shiftStartDate, 'yyyy-MM-dd');
      const res = await apiRequest('GET', `/api/attendance/user/${shift.assignedDriver}`);
      const driverAttendance = await res.json();
      
      // Check if there's already an attendance record for this date
      const existingAttendance = driverAttendance.find(
        (record: any) => record.date === formattedDate
      );
      
      if (!existingAttendance) {
        // Create an absence record
        await apiRequest('POST', '/api/attendance', {
          userId: shift.assignedDriver,
          startTime: shiftStartDate.toISOString(),
          endTime: shiftStartDate.toISOString(), // Same time to indicate no work done
          status: 'Absent',
          date: formattedDate
        });
        
        // Update shift status to Absent
        await apiRequest('PATCH', `/api/shifts/${shift.id}`, {
          shiftStatus: 'Absent'
        });
        
        // Refresh data
        await queryClient.invalidateQueries({ queryKey: ['/api/shifts'] });
        await queryClient.invalidateQueries({ queryKey: ['/api/attendance/date'] });
        
        return true;
      }
    }
    
    return false;
  } catch (error) {
    console.error('Error in checkAndMarkAbsent:', error);
    return false;
  }
}

/**
 * Runs the absence check for all scheduled shifts
 */
export async function checkAllDrivers(): Promise<number> {
  try {
    // Get today's date in yyyy-MM-dd format
    const today = format(new Date(), 'yyyy-MM-dd');
    
    // Get all shifts for today
    const res = await apiRequest('GET', '/api/shifts');
    const shifts = await res.json();
    
    // Filter shifts for today
    const todayShifts = shifts.filter((shift: Shift) => shift.shiftDate === today);
    
    let markedAbsentCount = 0;
    
    // Check each shift
    for (const shift of todayShifts) {
      const wasMarked = await checkAndMarkAbsent(shift);
      if (wasMarked) {
        markedAbsentCount++;
      }
    }
    
    return markedAbsentCount;
  } catch (error) {
    console.error('Error in checkAllDrivers:', error);
    return 0;
  }
}