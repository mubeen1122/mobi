import DriverLayout from "@/components/layout/driver-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { format, addDays, startOfDay, endOfDay, startOfWeek, endOfWeek, startOfMonth, endOfMonth, isSameDay } from "date-fns";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { type Shift } from "@shared/schema";
import { useState } from "react";
import { Loader2 } from "lucide-react";

export default function DriverSchedule() {
  const { user } = useAuth();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [timeframe, setTimeframe] = useState<'day' | 'week' | 'month'>('day');
  
  // Fetch all shifts for the driver
  const { data: shifts, isLoading } = useQuery<Shift[]>({
    queryKey: ["/api/shifts/driver", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const res = await apiRequest("GET", `/api/shifts/driver/${user.id}`);
      return await res.json();
    }
  });
  
  // Mutation for accepting a shift
  const acceptShiftMutation = useMutation({
    mutationFn: async (shiftId: number) => {
      const res = await apiRequest("PATCH", `/api/shifts/${shiftId}`, {
        shiftStatus: "Accepted"
      });
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shifts/driver", user?.id] });
    }
  });
  
  // Get shifts for the selected timeframe
  const getTimeframeShifts = () => {
    if (!shifts) return [];
    
    let startTime, endTime;
    
    if (timeframe === 'day') {
      startTime = startOfDay(selectedDate);
      endTime = endOfDay(selectedDate);
    } else if (timeframe === 'week') {
      startTime = startOfWeek(selectedDate, { weekStartsOn: 0 }); // Sunday
      endTime = endOfWeek(selectedDate, { weekStartsOn: 0 });
    } else { // month
      startTime = startOfMonth(selectedDate);
      endTime = endOfMonth(selectedDate);
    }
    
    return shifts.filter(shift => {
      const shiftDate = new Date(shift.shiftDate);
      return shiftDate >= startTime && shiftDate <= endTime;
    }).sort((a, b) => new Date(a.shiftDate).getTime() - new Date(b.shiftDate).getTime());
  };
  
  // Format shift times for display
  const formatShiftTime = (shift: Shift) => {
    return `${shift.startTime} - ${shift.endTime}`;
  };
  
  // Get shift status badge color
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'Scheduled':
        return <Badge variant="outline">Scheduled</Badge>;
      case 'Accepted':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-200">Accepted</Badge>;
      case 'Completed':
        return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">Completed</Badge>;
      case 'Absent':
        return <Badge variant="destructive">Absent</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };
  
  // Generate day buttons for the week view
  const weekDays = Array.from({ length: 7 }, (_, i) => {
    const day = addDays(startOfWeek(selectedDate, { weekStartsOn: 0 }), i);
    return {
      date: day,
      label: format(day, 'EEE'),
      dateNum: format(day, 'd')
    };
  });
  
  // Handle accepting a shift
  const handleAcceptShift = (shiftId: number) => {
    acceptShiftMutation.mutate(shiftId);
  };
  
  // Get filtered shifts based on timeframe
  const timeframeShifts = getTimeframeShifts();

  return (
    <DriverLayout>
      <div className="p-4">
        <Card>
          <CardHeader>
            <CardTitle>My Schedule</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs value={timeframe} onValueChange={(v) => setTimeframe(v as any)}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="day">Day</TabsTrigger>
                <TabsTrigger value="week">Week</TabsTrigger>
                <TabsTrigger value="month">Month</TabsTrigger>
              </TabsList>
              
              {/* Day View */}
              <TabsContent value="day" className="mt-4">
                <div className="flex justify-between items-center mb-4">
                  <Button variant="outline" size="sm" onClick={() => setSelectedDate(addDays(selectedDate, -1))}>
                    Previous Day
                  </Button>
                  <h3 className="text-lg font-medium">{format(selectedDate, 'MMMM d, yyyy')}</h3>
                  <Button variant="outline" size="sm" onClick={() => setSelectedDate(addDays(selectedDate, 1))}>
                    Next Day
                  </Button>
                </div>
                
                {isLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : timeframeShifts.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    No shifts scheduled for this day
                  </div>
                ) : (
                  <div className="space-y-4">
                    {timeframeShifts.map((shift) => (
                      <div key={shift.id} className="p-4 border rounded-md">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-medium">
                              {shift.startTime.includes('07:') ? 'Morning Shift' : 
                               shift.startTime.includes('15:') ? 'Afternoon Shift' : 
                               'Evening Shift'}
                            </h4>
                            <p className="text-sm text-gray-600">{formatShiftTime(shift)}</p>
                          </div>
                          <div>{getStatusBadge(shift.shiftStatus)}</div>
                        </div>
                        
                        {shift.shiftStatus === 'Scheduled' && (
                          <div className="mt-4">
                            <Button 
                              size="sm" 
                              onClick={() => handleAcceptShift(shift.id)}
                              disabled={acceptShiftMutation.isPending}
                            >
                              {acceptShiftMutation.isPending ? (
                                <>
                                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                  Accepting...
                                </>
                              ) : "Accept Shift"}
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </TabsContent>
              
              {/* Week View */}
              <TabsContent value="week" className="mt-4">
                <div className="flex justify-between items-center mb-4">
                  <Button variant="outline" size="sm" onClick={() => setSelectedDate(addDays(selectedDate, -7))}>
                    Previous Week
                  </Button>
                  <h3 className="text-lg font-medium">
                    {format(startOfWeek(selectedDate, { weekStartsOn: 0 }), 'MMM d')} - 
                    {format(endOfWeek(selectedDate, { weekStartsOn: 0 }), ' MMM d, yyyy')}
                  </h3>
                  <Button variant="outline" size="sm" onClick={() => setSelectedDate(addDays(selectedDate, 7))}>
                    Next Week
                  </Button>
                </div>
                
                <div className="grid grid-cols-7 gap-2 mb-4">
                  {weekDays.map((day) => (
                    <Button 
                      key={day.label} 
                      variant={isSameDay(day.date, selectedDate) ? "default" : "outline"}
                      className="flex flex-col h-auto py-2"
                      onClick={() => setSelectedDate(day.date)}
                    >
                      <span className="text-xs">{day.label}</span>
                      <span className="text-lg">{day.dateNum}</span>
                    </Button>
                  ))}
                </div>
                
                {isLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : timeframeShifts.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    No shifts scheduled for this week
                  </div>
                ) : (
                  <div className="space-y-4">
                    {timeframeShifts.map((shift) => (
                      <div key={shift.id} className="p-4 border rounded-md">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-medium">
                              {format(new Date(shift.shiftDate), 'EEEE, MMMM d')}
                            </h4>
                            <p className="text-sm text-gray-600">{formatShiftTime(shift)}</p>
                          </div>
                          <div>{getStatusBadge(shift.shiftStatus)}</div>
                        </div>
                        
                        {shift.shiftStatus === 'Scheduled' && (
                          <div className="mt-4">
                            <Button 
                              size="sm" 
                              onClick={() => handleAcceptShift(shift.id)}
                              disabled={acceptShiftMutation.isPending}
                            >
                              {acceptShiftMutation.isPending ? (
                                <>
                                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                  Accepting...
                                </>
                              ) : "Accept Shift"}
                            </Button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </TabsContent>
              
              {/* Month View */}
              <TabsContent value="month" className="mt-4">
                <div className="flex justify-between items-center mb-4">
                  <Button variant="outline" size="sm" onClick={() => {
                    const newDate = new Date(selectedDate);
                    newDate.setMonth(newDate.getMonth() - 1);
                    setSelectedDate(newDate);
                  }}>
                    Previous Month
                  </Button>
                  <h3 className="text-lg font-medium">{format(selectedDate, 'MMMM yyyy')}</h3>
                  <Button variant="outline" size="sm" onClick={() => {
                    const newDate = new Date(selectedDate);
                    newDate.setMonth(newDate.getMonth() + 1);
                    setSelectedDate(newDate);
                  }}>
                    Next Month
                  </Button>
                </div>
                
                {isLoading ? (
                  <div className="flex justify-center py-8">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : timeframeShifts.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    No shifts scheduled for this month
                  </div>
                ) : (
                  <div className="space-y-1">
                    {timeframeShifts.map((shift, index) => (
                      <div key={shift.id}>
                        {index > 0 && <Separator className="my-2" />}
                        <div className="p-3 rounded-md">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-medium">
                                {format(new Date(shift.shiftDate), 'EEEE, MMMM d')}
                              </h4>
                              <p className="text-sm text-gray-600">{formatShiftTime(shift)}</p>
                            </div>
                            <div>{getStatusBadge(shift.shiftStatus)}</div>
                          </div>
                          
                          {shift.shiftStatus === 'Scheduled' && (
                            <div className="mt-3">
                              <Button 
                                size="sm" 
                                onClick={() => handleAcceptShift(shift.id)}
                                disabled={acceptShiftMutation.isPending}
                              >
                                {acceptShiftMutation.isPending ? (
                                  <>
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                    Accepting...
                                  </>
                                ) : "Accept Shift"}
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </DriverLayout>
  );
}
