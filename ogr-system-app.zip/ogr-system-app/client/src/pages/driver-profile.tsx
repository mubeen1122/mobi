import DriverLayout from "@/components/layout/driver-layout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Loader2, Truck, Clock, Mail, Phone, User } from "lucide-react";
import { format, parseISO } from "date-fns";

export default function DriverProfile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    phone: "",
  });
  
  // Fetch attendance history
  const { data: attendanceData, isLoading: attendanceLoading } = useQuery({
    queryKey: ["/api/attendance/user", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const res = await apiRequest("GET", `/api/attendance/user/${user.id}`);
      return await res.json();
    }
  });
  
  // Update user profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      if (!user) throw new Error("User not found");
      const res = await apiRequest("PATCH", `/api/users/${user.id}`, data);
      return await res.json();
    },
    onSuccess: (updatedUser) => {
      queryClient.setQueryData(["/api/user"], updatedUser);
      setIsEditing(false);
      toast({
        title: "Profile updated",
        description: "Your profile information has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
  
  // Handle form changes
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileMutation.mutate(formData);
  };
  
  // Calculate stats
  const calculateStats = () => {
    if (!attendanceData || !Array.isArray(attendanceData)) {
      return {
        totalHours: 0,
        completedShifts: 0,
        avgHoursPerShift: 0
      };
    }
    
    const completedAttendance = attendanceData.filter(a => a.endTime);
    
    // Calculate total hours
    const totalHours = completedAttendance.reduce((total, record) => {
      const startTime = new Date(record.startTime).getTime();
      const endTime = new Date(record.endTime).getTime();
      const hoursWorked = (endTime - startTime) / (1000 * 60 * 60);
      return total + hoursWorked;
    }, 0);
    
    return {
      totalHours: totalHours.toFixed(1),
      completedShifts: completedAttendance.length,
      avgHoursPerShift: completedAttendance.length > 0 
        ? (totalHours / completedAttendance.length).toFixed(1) 
        : 0
    };
  };
  
  const stats = calculateStats();

  return (
    <DriverLayout>
      <div className="p-4">
        <h1 className="text-xl font-bold mb-4">My Profile</h1>
        
        {/* Profile Card */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center space-x-4">
              <div className="h-16 w-16 rounded-full bg-primary-100 flex items-center justify-center text-primary-700 text-xl font-semibold">
                {user?.name?.split(' ').map(n => n[0]).join('')}
              </div>
              <div>
                <CardTitle>{user?.name}</CardTitle>
                <CardDescription>{user?.role}</CardDescription>
              </div>
            </div>
          </CardHeader>
          
          <CardContent>
            {isEditing ? (
              <form onSubmit={handleSubmit}>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input 
                      id="name" 
                      name="name" 
                      value={formData.name} 
                      onChange={handleChange} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input 
                      id="email" 
                      name="email" 
                      type="email" 
                      value={formData.email} 
                      onChange={handleChange} 
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input 
                      id="phone" 
                      name="phone" 
                      type="tel" 
                      value={formData.phone} 
                      onChange={handleChange} 
                    />
                  </div>
                </div>
                
                <div className="flex space-x-2 mt-6">
                  <Button type="submit" disabled={updateProfileMutation.isPending}>
                    {updateProfileMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : "Save Changes"}
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>
                    Cancel
                  </Button>
                </div>
              </form>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center">
                  <User className="h-5 w-5 text-gray-500 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Username</p>
                    <p>{user?.username}</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <Mail className="h-5 w-5 text-gray-500 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Email</p>
                    <p>{user?.email || "Not set"}</p>
                  </div>
                </div>
                
                <div className="flex items-center">
                  <Truck className="h-5 w-5 text-gray-500 mr-3" />
                  <div>
                    <p className="text-sm text-gray-500">Assigned Truck</p>
                    <p>{user?.assignedTruck || "None assigned"}</p>
                  </div>
                </div>
                
                <Button className="mt-2" onClick={() => setIsEditing(true)}>
                  Edit Profile
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Stats Card */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-lg">Work Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold">{stats.totalHours}</div>
                <div className="text-sm text-gray-500">Total Hours</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{stats.completedShifts}</div>
                <div className="text-sm text-gray-500">Completed Shifts</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{stats.avgHoursPerShift}</div>
                <div className="text-sm text-gray-500">Avg Hours/Shift</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            {attendanceLoading ? (
              <div className="flex justify-center py-4">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : !attendanceData || attendanceData.length === 0 ? (
              <div className="text-center py-4 text-gray-500">
                No activity recorded yet
              </div>
            ) : (
              <div className="space-y-4">
                {attendanceData.slice(0, 5).map((activity: any) => (
                  <div key={activity.id} className="flex items-start space-x-3">
                    <Clock className="h-5 w-5 text-gray-500 mt-0.5" />
                    <div className="flex-1">
                      <p className="font-medium">
                        {activity.endTime ? 'Completed duty' : 'Started duty'}
                      </p>
                      <div className="flex justify-between">
                        <p className="text-sm text-gray-600">
                          {activity.vehicleNumber ? `Vehicle: ${activity.vehicleNumber}` : 'No vehicle specified'}
                        </p>
                        <p className="text-sm text-gray-600">
                          {format(new Date(activity.startTime), 'MMM d, h:mm a')}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DriverLayout>
  );
}
