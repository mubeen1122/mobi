import { useState } from "react";
import AdminLayout from "@/components/layout/admin-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { type User, type Truck, type Shift } from "@shared/schema";
import { format, addHours, setHours, setMinutes } from "date-fns";
import { Loader2, PlusCircle, Calendar, Clock, CalendarClock } from "lucide-react";
import { LATE_THRESHOLD_MINUTES } from "@/services/attendance-checker";

export default function AdminDutyAssignment() {
  const { toast } = useToast();
  const [isAddDutyOpen, setIsAddDutyOpen] = useState(false);
  const [selectedDate, setSelectedDate] = useState<string>(format(new Date(), "yyyy-MM-dd"));
  const [selectedDriver, setSelectedDriver] = useState<string>("");
  const [selectedTruck, setSelectedTruck] = useState<string>("");
  const [startTime, setStartTime] = useState<string>("09:00");
  const [endTime, setEndTime] = useState<string>("17:00");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch drivers (users with driver role)
  const { data: users, isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/users");
      return await res.json();
    }
  });

  // Fetch available trucks
  const { data: trucks, isLoading: trucksLoading } = useQuery<Truck[]>({
    queryKey: ["/api/trucks"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/trucks");
      return await res.json();
    }
  });

  // Fetch shifts
  const { data: shifts, isLoading: shiftsLoading } = useQuery<Shift[]>({
    queryKey: ["/api/shifts"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/shifts");
      return await res.json();
    }
  });

  // Create shift mutation
  const createShiftMutation = useMutation({
    mutationFn: async (shiftData: {
      shiftDate: string;
      startTime: string;
      endTime: string;
      assignedDriver: number;
      assignedTruck: string;
      shiftStatus: string;
    }) => {
      const res = await apiRequest("POST", "/api/shifts", shiftData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shifts"] });
      toast({
        title: "Success",
        description: "Duty assignment created successfully.",
      });
      setIsAddDutyOpen(false);
      resetForm();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create duty assignment.",
        variant: "destructive",
      });
    },
  });

  // Filter only driver users
  const drivers = users?.filter(user => user.role === "driver") || [];
  
  // Filter available trucks (not assigned to any active shift)
  const availableTrucks = trucks?.filter(truck => 
    truck.status === "Active" && 
    !shifts?.some(shift => 
      shift.shiftDate === selectedDate && 
      truck.id.toString() === shift.assignedTruck
    )
  ) || [];

  // Get shifts for the selected date
  const shiftsForDate = shifts?.filter(shift => shift.shiftDate === selectedDate) || [];

  // Handle form submission
  const handleSubmit = () => {
    if (!selectedDriver || !selectedTruck || !startTime || !endTime) {
      toast({
        title: "Validation Error",
        description: "Please fill all required fields.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    createShiftMutation.mutate({
      shiftDate: selectedDate,
      startTime: startTime,
      endTime: endTime,
      assignedDriver: parseInt(selectedDriver),
      assignedTruck: selectedTruck,
      shiftStatus: "Scheduled"
    });
  };

  // Reset form fields
  const resetForm = () => {
    setSelectedDriver("");
    setSelectedTruck("");
    setStartTime("09:00");
    setEndTime("17:00");
    setIsSubmitting(false);
  };

  // Get driver name by ID
  const getDriverName = (id: number | null) => {
    if (!id) return "Unassigned";
    const driver = users?.find(user => user.id === id);
    return driver ? driver.name : "Unknown";
  };

  // Get truck number by ID
  const getTruckNumber = (id: number | string) => {
    const truck = trucks?.find(t => t.id.toString() === id.toString());
    return truck ? truck.truckNumber : "Unknown";
  };

  return (
    <AdminLayout>
      <div className="p-6">
        <header className="flex justify-between items-center mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Duty Assignment</h1>
            <p className="text-gray-600">Assign duties to drivers and trucks</p>
          </div>
          <Button onClick={() => setIsAddDutyOpen(true)}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Assign New Duty
          </Button>
        </header>

        {/* Date selector */}
        <div className="mb-6">
          <Label htmlFor="date-select" className="mb-2 block">Select Date</Label>
          <div className="flex max-w-sm">
            <Input
              id="date-select"
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="flex-1"
            />
          </div>
        </div>

        {/* Duty Assignments Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <CalendarClock className="mr-2 h-5 w-5" />
              Duty Assignments for {format(new Date(selectedDate), "MMMM d, yyyy")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {shiftsLoading || usersLoading || trucksLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : shiftsForDate.length === 0 ? (
              <div className="py-8 text-center text-gray-500">
                <p>No duties assigned for this date.</p>
                <p className="text-sm mt-1">Click "Assign New Duty" to create one.</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Driver</TableHead>
                    <TableHead>Truck</TableHead>
                    <TableHead>Start Time</TableHead>
                    <TableHead>End Time</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Absence Threshold</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {shiftsForDate.map((shift) => (
                    <TableRow key={shift.id}>
                      <TableCell className="font-medium">{getDriverName(shift.assignedDriver)}</TableCell>
                      <TableCell>{getTruckNumber(shift.assignedTruck || "")}</TableCell>
                      <TableCell>{shift.startTime}</TableCell>
                      <TableCell>{shift.endTime}</TableCell>
                      <TableCell>
                        <span 
                          className={`px-2 py-1 rounded-md text-xs font-medium ${
                            shift.shiftStatus === "Scheduled" ? "bg-blue-100 text-blue-800" :
                            shift.shiftStatus === "Completed" ? "bg-green-100 text-green-800" :
                            shift.shiftStatus === "In Progress" ? "bg-yellow-100 text-yellow-800" :
                            shift.shiftStatus === "Absent" ? "bg-red-100 text-red-800" :
                            "bg-gray-100 text-gray-800"
                          }`}
                        >
                          {shift.shiftStatus}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Clock className="mr-1 h-4 w-4 text-gray-400" />
                          <span className="text-sm text-gray-600">
                            {LATE_THRESHOLD_MINUTES} min after start
                          </span>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Driver Availability Overview */}
        <div className="mt-6">
          <h2 className="text-xl font-semibold mb-4">Driver & Truck Availability</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Available Drivers</CardTitle>
              </CardHeader>
              <CardContent>
                {usersLoading ? (
                  <div className="flex justify-center py-4">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : drivers.length === 0 ? (
                  <p className="text-gray-500">No drivers available.</p>
                ) : (
                  <div className="space-y-2">
                    {drivers.map(driver => {
                      const isAssigned = shiftsForDate.some(shift => shift.assignedDriver === driver.id);
                      return (
                        <div key={driver.id} className="flex justify-between p-2 border-b">
                          <span className="font-medium">{driver.name}</span>
                          <span className={`text-sm ${isAssigned ? "text-orange-600" : "text-green-600"}`}>
                            {isAssigned ? "Assigned" : "Available"}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Available Trucks</CardTitle>
              </CardHeader>
              <CardContent>
                {trucksLoading ? (
                  <div className="flex justify-center py-4">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : trucks?.length === 0 ? (
                  <p className="text-gray-500">No trucks available.</p>
                ) : (
                  <div className="space-y-2">
                    {trucks?.map(truck => {
                      const isAssigned = shiftsForDate.some(shift => shift.assignedTruck === truck.id.toString());
                      return (
                        <div key={truck.id} className="flex justify-between p-2 border-b">
                          <span className="font-medium">{truck.truckNumber}</span>
                          <span className={`text-sm ${isAssigned ? "text-orange-600" : 
                          (truck.status !== "Active" ? "text-red-600" : "text-green-600")}`}>
                            {isAssigned ? "Assigned" : 
                             (truck.status !== "Active" ? truck.status : "Available")}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Add Duty Assignment Dialog */}
        <Dialog open={isAddDutyOpen} onOpenChange={setIsAddDutyOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Assign New Duty</DialogTitle>
              <DialogDescription>
                Create a new duty assignment for a driver and truck.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="duty-date">Date</Label>
                <Input
                  id="duty-date"
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="driver-select">Driver</Label>
                <Select value={selectedDriver} onValueChange={setSelectedDriver}>
                  <SelectTrigger id="driver-select">
                    <SelectValue placeholder="Select driver" />
                  </SelectTrigger>
                  <SelectContent>
                    {drivers.map(driver => (
                      <SelectItem key={driver.id} value={driver.id.toString()}>
                        {driver.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="truck-select">Truck</Label>
                <Select value={selectedTruck} onValueChange={setSelectedTruck}>
                  <SelectTrigger id="truck-select">
                    <SelectValue placeholder="Select truck" />
                  </SelectTrigger>
                  <SelectContent>
                    {trucks?.filter(truck => truck.status === "Active").map(truck => (
                      <SelectItem key={truck.id} value={truck.id.toString()}>
                        {truck.truckNumber}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="start-time">Start Time</Label>
                  <Input
                    id="start-time"
                    type="time"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="end-time">End Time</Label>
                  <Input
                    id="end-time"
                    type="time"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                  />
                </div>
              </div>

              <div className="bg-amber-50 p-3 rounded-md text-sm border border-amber-200">
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-2 text-amber-600" />
                  <span className="font-medium text-amber-700">Automatic Absence Marking</span>
                </div>
                <p className="mt-1 text-amber-800">
                  If the driver doesn't log in and start duty within {LATE_THRESHOLD_MINUTES} minutes of the scheduled start time, 
                  they will be automatically marked as absent.
                </p>
              </div>
            </div>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsAddDutyOpen(false)}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              <Button 
                onClick={handleSubmit}
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating...
                  </>
                ) : (
                  "Create Duty Assignment"
                )}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}