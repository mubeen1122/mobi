import { useState } from "react";
import AdminLayout from "@/components/layout/admin-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { type Shift, insertShiftSchema } from "@shared/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { format, parse, isValid } from "date-fns";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CalendarIcon, Loader2, Search, Plus } from "lucide-react";

// Extend schema with better validation
const shiftFormSchema = z.object({
  shiftDate: z.date({
    required_error: "Please select a date for the shift",
  }),
  startTime: z.string().min(1, "Start time is required"),
  endTime: z.string().min(1, "End time is required"),
  assignedDriver: z.number().optional(),
  shiftStatus: z.string().default("Scheduled"),
});

type ShiftFormValues = z.infer<typeof shiftFormSchema>;

export default function AdminShifts() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingShift, setEditingShift] = useState<Shift | null>(null);
  const [statusFilter, setStatusFilter] = useState("all");

  // Fetch all shifts
  const { data: shifts, isLoading: shiftsLoading } = useQuery<Shift[]>({
    queryKey: ["/api/shifts"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/shifts");
      return await res.json();
    },
  });

  // Fetch users for driver selection
  const { data: users } = useQuery({
    queryKey: ["/api/users"],
    queryFn: async () => {
      try {
        // For demo, we'll simulate by fetching user 1 and 2
        const res1 = await apiRequest("GET", `/api/users/1`);
        const admin = await res1.json();
        
        const res2 = await apiRequest("GET", `/api/users/2`);
        const driver = await res2.json();
        
        return [admin, driver];
      } catch (error) {
        console.error("Error fetching users:", error);
        return [];
      }
    }
  });

  // Create shift mutation
  const createShiftMutation = useMutation({
    mutationFn: async (shiftData: Omit<ShiftFormValues, "shiftDate"> & { shiftDate: string }) => {
      const res = await apiRequest("POST", "/api/shifts", shiftData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shifts"] });
      setIsDialogOpen(false);
      toast({
        title: "Success",
        description: "Shift has been added successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update shift mutation
  const updateShiftMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Shift> }) => {
      const res = await apiRequest("PATCH", `/api/shifts/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/shifts"] });
      setIsDialogOpen(false);
      setEditingShift(null);
      toast({
        title: "Success",
        description: "Shift has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Form for creating/editing shifts
  const form = useForm<ShiftFormValues>({
    resolver: zodResolver(shiftFormSchema),
    defaultValues: {
      shiftDate: new Date(),
      startTime: "08:00",
      endTime: "16:00",
      shiftStatus: "Scheduled",
    },
  });

  // Reset and open form for creating a new shift
  const handleAddShift = () => {
    form.reset({
      shiftDate: new Date(),
      startTime: "08:00",
      endTime: "16:00",
      shiftStatus: "Scheduled",
    });
    setEditingShift(null);
    setIsDialogOpen(true);
  };

  // Open form for editing a shift
  const handleEditShift = (shift: Shift) => {
    // Parse shift date from string to Date object
    const shiftDate = parse(shift.shiftDate, "yyyy-MM-dd", new Date());
    
    form.reset({
      shiftDate,
      startTime: shift.startTime,
      endTime: shift.endTime,
      assignedDriver: shift.assignedDriver,
      shiftStatus: shift.shiftStatus,
    });
    setEditingShift(shift);
    setIsDialogOpen(true);
  };

  // Handle form submission
  const onSubmit = (data: ShiftFormValues) => {
    // Format date for API
    const formattedData = {
      ...data,
      shiftDate: format(data.shiftDate, "yyyy-MM-dd"),
    };
    
    if (editingShift) {
      updateShiftMutation.mutate({ id: editingShift.id, data: formattedData });
    } else {
      createShiftMutation.mutate(formattedData);
    }
  };

  // Filter and sort shifts based on search and status
  const filteredShifts = shifts
    ?.filter((shift) => {
      // Filter by status if not "all"
      if (statusFilter !== "all" && shift.shiftStatus !== statusFilter) {
        return false;
      }
      
      // Filter by search term
      const driverName = users?.find(user => user.id === shift.assignedDriver)?.name?.toLowerCase() || "";
      return (
        shift.shiftDate.toLowerCase().includes(search.toLowerCase()) ||
        driverName.includes(search.toLowerCase())
      );
    })
    .sort((a, b) => {
      // Sort by date (most recent first)
      return new Date(b.shiftDate).getTime() - new Date(a.shiftDate).getTime();
    }) || [];

  // Helper to get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Scheduled":
        return <Badge variant="outline">Scheduled</Badge>;
      case "Accepted":
        return <Badge className="bg-green-100 text-green-800">Accepted</Badge>;
      case "Completed":
        return <Badge className="bg-blue-100 text-blue-800">Completed</Badge>;
      case "Absent":
        return <Badge variant="destructive">Absent</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  // Helper to get driver name
  const getDriverName = (driverId?: number) => {
    if (!driverId) return "Unassigned";
    return users?.find(user => user.id === driverId)?.name || "Unknown";
  };

  return (
    <AdminLayout>
      <div className="p-6">
        <header className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Shift Management</h1>
            <p className="text-gray-600">Schedule and manage driver shifts</p>
          </div>
          <Button 
            className="mt-4 sm:mt-0"
            onClick={handleAddShift}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Shift
          </Button>
        </header>

        {/* Search and Filter */}
        <div className="mb-6 flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search shifts by date or driver..."
              className="pl-10"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Select
            value={statusFilter}
            onValueChange={setStatusFilter}
          >
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="Scheduled">Scheduled</SelectItem>
              <SelectItem value="Accepted">Accepted</SelectItem>
              <SelectItem value="Completed">Completed</SelectItem>
              <SelectItem value="Absent">Absent</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Shifts List */}
        <Card>
          <CardHeader>
            <CardTitle>Shifts</CardTitle>
          </CardHeader>
          <CardContent>
            {shiftsLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredShifts.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No shifts found matching your search criteria
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Time
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Assigned Driver
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredShifts.map((shift) => {
                      // Parse the shift date string into a Date object
                      const shiftDate = parse(shift.shiftDate, "yyyy-MM-dd", new Date());
                      const isValidDate = isValid(shiftDate);
                      
                      return (
                        <tr key={shift.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">
                              {isValidDate ? format(shiftDate, "EEE, MMM d, yyyy") : shift.shiftDate}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">
                              {shift.startTime} - {shift.endTime}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">
                              {getDriverName(shift.assignedDriver)}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {getStatusBadge(shift.shiftStatus)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditShift(shift)}
                              className="text-primary-600 hover:text-primary-900"
                            >
                              Edit
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Add/Edit Shift Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingShift ? 'Edit Shift' : 'Add New Shift'}
              </DialogTitle>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="shiftDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Shift Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={`w-full pl-3 text-left font-normal ${
                                !field.value ? "text-muted-foreground" : ""
                              }`}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="startTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Start Time</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="time"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="endTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>End Time</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            type="time"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="assignedDriver"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Assigned Driver</FormLabel>
                      <Select 
                        onValueChange={(value) => {
                          if (value === "unassigned") {
                            field.onChange(undefined);
                          } else {
                            field.onChange(Number(value));
                          }
                        }} 
                        value={field.value?.toString() || "unassigned"}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a driver (optional)" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="unassigned">Unassigned</SelectItem>
                          {users?.filter(user => user.role === 'driver').map((driver) => (
                            <SelectItem key={driver.id} value={driver.id.toString()}>
                              {driver.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="shiftStatus"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Scheduled">Scheduled</SelectItem>
                          <SelectItem value="Accepted">Accepted</SelectItem>
                          <SelectItem value="Completed">Completed</SelectItem>
                          <SelectItem value="Absent">Absent</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter className="mt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsDialogOpen(false)}
                    disabled={createShiftMutation.isPending || updateShiftMutation.isPending}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={createShiftMutation.isPending || updateShiftMutation.isPending}
                  >
                    {(createShiftMutation.isPending || updateShiftMutation.isPending) ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : editingShift ? 'Update Shift' : 'Add Shift'}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
