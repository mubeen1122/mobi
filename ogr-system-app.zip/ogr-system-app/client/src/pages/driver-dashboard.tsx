import DriverLayout from "@/components/layout/driver-layout";
import DutyCard from "@/components/duty-card";
import CalendarView from "@/components/calendar-view";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { type Shift } from "@shared/schema";
import { format } from "date-fns";
import { useCallback, useEffect, useState } from "react";

export default function DriverDashboard() {
  const { user } = useAuth();
  const [currentMonth, setCurrentMonth] = useState<Date>(new Date());
  const [activeDuty, setActiveDuty] = useState<any | null>(null);
  
  // Fetch shifts
  const { data: shifts, isLoading: shiftsLoading } = useQuery<Shift[]>({
    queryKey: ["/api/shifts/driver", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const res = await apiRequest("GET", `/api/shifts/driver/${user.id}`);
      return await res.json();
    }
  });
  
  // Fetch attendance (active duty)
  const { data: attendanceData, isLoading: attendanceLoading, refetch: refetchAttendance } = useQuery({
    queryKey: ["/api/attendance/user", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const res = await apiRequest("GET", `/api/attendance/user/${user.id}`);
      return await res.json();
    }
  });
  
  // Check for active duty
  useEffect(() => {
    if (attendanceData && Array.isArray(attendanceData)) {
      // Find attendance record without an end time (active duty)
      const active = attendanceData.find(item => !item.endTime && item.date === format(new Date(), 'yyyy-MM-dd'));
      if (active) {
        setActiveDuty(active);
      } else {
        setActiveDuty(null);
      }
    }
  }, [attendanceData]);
  
  // Format upcoming shifts
  const upcomingShifts = shifts?.filter(shift => {
    const shiftDate = new Date(shift.shiftDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return shiftDate >= today && shift.shiftStatus !== 'Completed';
  }).sort((a, b) => {
    return new Date(a.shiftDate).getTime() - new Date(b.shiftDate).getTime();
  }) || [];
  
  // Handle shift accept
  const handleAcceptShift = useCallback(async (shiftId: number) => {
    try {
      await apiRequest("PATCH", `/api/shifts/${shiftId}`, {
        shiftStatus: "Accepted"
      });
    } catch (error) {
      console.error("Error accepting shift:", error);
    }
  }, []);
  
  // Handle shift swap request
  const handleSwapRequest = useCallback((shiftId: number) => {
    // In a full implementation, this would open a modal to select another driver
    alert("Swap request functionality would be implemented here");
  }, []);

  return (
    <DriverLayout>
      <div className="p-4">
        {/* Current Duty Card */}
        <DutyCard 
          activeDuty={activeDuty} 
          onDutyEnd={refetchAttendance}
        />
        
        {/* Schedule Section */}
        <div className="mt-6">
          <h2 className="text-lg font-semibold mb-4">My Schedule</h2>
          
          {/* Calendar View */}
          <Card className="mb-4">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <CardTitle className="text-base font-medium">
                  {format(currentMonth, 'MMMM yyyy')}
                </CardTitle>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => {
                      const newDate = new Date(currentMonth);
                      newDate.setMonth(newDate.getMonth() - 1);
                      setCurrentMonth(newDate);
                    }}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                    </svg>
                  </Button>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => {
                      const newDate = new Date(currentMonth);
                      newDate.setMonth(newDate.getMonth() + 1);
                      setCurrentMonth(newDate);
                    }}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <CalendarView 
                currentMonth={currentMonth} 
                shifts={shifts || []} 
                loading={shiftsLoading}
              />
              
              <div className="mt-4 flex items-center justify-between text-sm">
                <div className="flex items-center">
                  <span className="block w-3 h-3 rounded-full bg-primary mr-1"></span>
                  <span>Scheduled</span>
                </div>
                <div className="flex items-center">
                  <span className="block w-3 h-3 rounded-full bg-green-500 mr-1"></span>
                  <span>Completed</span>
                </div>
                <div className="flex items-center">
                  <span className="block w-3 h-3 rounded-full bg-yellow-500 mr-1"></span>
                  <span>Pending</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Upcoming Shifts */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-medium">Upcoming Shifts</CardTitle>
            </CardHeader>
            <CardContent className="space-y-0">
              {upcomingShifts.length === 0 ? (
                <div className="text-center py-6 text-gray-500">
                  No upcoming shifts scheduled
                </div>
              ) : (
                upcomingShifts.map((shift, index) => (
                  <div key={shift.id} className="py-3">
                    {index > 0 && <Separator className="mb-3" />}
                    <div className="flex justify-between">
                      <div>
                        <h4 className="font-medium">
                          {shift.startTime.includes('07:') ? 'Morning Shift' : 
                           shift.startTime.includes('15:') ? 'Afternoon Shift' : 
                           'Evening Shift'}
                        </h4>
                        <p className="text-sm text-gray-600">
                          {shift.shiftStatus === 'Accepted' ? (
                            `Truck: ${user?.assignedTruck || 'Not assigned'}`
                          ) : 'Truck assignment pending'}
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="block text-sm font-medium">
                          {format(new Date(shift.shiftDate), 'MMM d, yyyy')}
                        </span>
                        <span className="block text-sm text-gray-600">
                          {shift.startTime} - {shift.endTime}
                        </span>
                      </div>
                    </div>
                    
                    {shift.shiftStatus === 'Scheduled' && (
                      <div className="mt-2 flex space-x-2">
                        <Button 
                          size="sm"
                          onClick={() => handleAcceptShift(shift.id)}
                        >
                          Accept
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleSwapRequest(shift.id)}
                        >
                          Request Swap
                        </Button>
                      </div>
                    )}
                    
                    {shift.shiftStatus === 'Accepted' && (
                      <div className="mt-2">
                        <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
                          Accepted
                        </Badge>
                      </div>
                    )}
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </DriverLayout>
  );
}
