import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { Loader2, MapPin, Edit, Trash, Check } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import AdminLayout from '@/components/layout/admin-layout';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';

// Form schema for creating/editing workplace locations
const locationFormSchema = z.object({
  name: z.string().min(1, { message: 'Location name is required' }),
  latitude: z.string().min(1, { message: 'Latitude is required' }),
  longitude: z.string().min(1, { message: 'Longitude is required' }),
  radiusInMeters: z.coerce.number().min(50, { message: 'Radius must be at least 50 meters' }),
  isActive: z.boolean().default(true)
});

type LocationFormValues = z.infer<typeof locationFormSchema>;

export default function AdminLocations() {
  const [editingLocationId, setEditingLocationId] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Initialize form
  const form = useForm<LocationFormValues>({
    resolver: zodResolver(locationFormSchema),
    defaultValues: {
      name: '',
      latitude: '',
      longitude: '',
      radiusInMeters: 100,
      isActive: true
    }
  });

  // Fetch workplace locations
  const { data: locations, isLoading } = useQuery({
    queryKey: ['/api/workplace-locations'],
    queryFn: async () => {
      const res = await fetch('/api/workplace-locations');
      return res.json();
    }
  });

  // Create new location
  const createLocationMutation = useMutation({
    mutationFn: async (data: LocationFormValues) => {
      const response = await apiRequest('POST', '/api/workplace-locations', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Success!',
        description: 'Location saved successfully.',
        variant: 'default',
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/workplace-locations'] });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: `Failed to save location: ${error.message}`,
        variant: 'destructive',
      });
    }
  });

  // Update existing location
  const updateLocationMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: LocationFormValues }) => {
      const response = await apiRequest('PATCH', `/api/workplace-locations/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Success!',
        description: 'Location updated successfully.',
        variant: 'default',
      });
      setEditingLocationId(null);
      form.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/workplace-locations'] });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: `Failed to update location: ${error.message}`,
        variant: 'destructive',
      });
    }
  });

  // Delete location
  const deleteLocationMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/workplace-locations/${id}`);
    },
    onSuccess: () => {
      toast({
        title: 'Success!',
        description: 'Location deleted successfully.',
        variant: 'default',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/workplace-locations'] });
    },
    onError: (error) => {
      toast({
        title: 'Error',
        description: `Failed to delete location: ${error.message}`,
        variant: 'destructive',
      });
    }
  });

  const handleEditLocation = (location: any) => {
    setEditingLocationId(location.id);
    form.reset({
      name: location.name,
      latitude: location.latitude,
      longitude: location.longitude,
      radiusInMeters: location.radiusInMeters,
      isActive: location.isActive
    });
  };

  const handleCancelEdit = () => {
    setEditingLocationId(null);
    form.reset();
  };

  const onSubmit = (data: LocationFormValues) => {
    if (editingLocationId) {
      updateLocationMutation.mutate({ id: editingLocationId, data });
    } else {
      createLocationMutation.mutate(data);
    }
  };

  // Get current location using browser geolocation API
  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          form.setValue('latitude', latitude.toString());
          form.setValue('longitude', longitude.toString());
          toast({
            title: 'Location detected',
            description: 'Current coordinates have been filled in.',
          });
        },
        (error) => {
          toast({
            title: 'Error',
            description: `Failed to get location: ${error.message}`,
            variant: 'destructive',
          });
        }
      );
    } else {
      toast({
        title: 'Error',
        description: 'Geolocation is not supported by this browser.',
        variant: 'destructive',
      });
    }
  };

  return (
    <AdminLayout>
      <div className="p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Workplace Locations</h1>
          <p className="text-gray-500">
            Set up and manage workplace locations for geofencing. Active locations will be used to detect when drivers are at the workplace.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>{editingLocationId ? 'Edit Location' : 'Add New Location'}</CardTitle>
                <CardDescription>
                  {editingLocationId 
                    ? 'Update the workplace location details' 
                    : 'Add a new workplace location for geofencing'}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Location Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Main Office" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-2 gap-3">
                      <FormField
                        control={form.control}
                        name="latitude"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Latitude</FormLabel>
                            <FormControl>
                              <Input placeholder="41.40338" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="longitude"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Longitude</FormLabel>
                            <FormControl>
                              <Input placeholder="2.17403" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="flex items-center justify-between py-2">
                      <Button 
                        type="button" 
                        variant="outline" 
                        size="sm"
                        onClick={getCurrentLocation}
                      >
                        <MapPin className="h-4 w-4 mr-2" />
                        Use Current Location
                      </Button>
                    </div>

                    <FormField
                      control={form.control}
                      name="radiusInMeters"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Radius (meters)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="100" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="isActive"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3 shadow-sm">
                          <div className="space-y-0.5">
                            <FormLabel>Active Location</FormLabel>
                            <p className="text-xs text-gray-500">
                              Make this the active workplace location
                            </p>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <div className="flex justify-end space-x-2 pt-2">
                      {editingLocationId && (
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={handleCancelEdit}
                        >
                          Cancel
                        </Button>
                      )}
                      <Button 
                        type="submit" 
                        disabled={createLocationMutation.isPending || updateLocationMutation.isPending}
                      >
                        {(createLocationMutation.isPending || updateLocationMutation.isPending) && (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        )}
                        {editingLocationId ? 'Update Location' : 'Add Location'}
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Workplace Locations</CardTitle>
                <CardDescription>
                  Manage your registered workplace locations
                </CardDescription>
              </CardHeader>
              <CardContent>
                {isLoading ? (
                  <div className="flex justify-center items-center py-10">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  </div>
                ) : locations && locations.length > 0 ? (
                  <div className="space-y-4">
                    {locations.map((location: any) => (
                      <Card key={location.id} className={`${location.isActive ? 'border-primary' : ''}`}>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium flex items-center">
                                {location.name}
                                {location.isActive && (
                                  <span className="ml-2 text-xs px-2 py-0.5 bg-primary/10 text-primary rounded-full flex items-center">
                                    <Check className="w-3 h-3 mr-1" />
                                    Active
                                  </span>
                                )}
                              </h3>
                              <div className="text-sm text-gray-500">
                                <div className="my-1">
                                  <span className="font-semibold">Coordinates:</span> {location.latitude}, {location.longitude}
                                </div>
                                <div>
                                  <span className="font-semibold">Radius:</span> {location.radiusInMeters} meters
                                </div>
                              </div>
                            </div>
                            <div className="flex space-x-2">
                              <Button 
                                variant="outline" 
                                size="icon"
                                onClick={() => handleEditLocation(location)}
                                disabled={editingLocationId === location.id}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="destructive" 
                                size="icon"
                                onClick={() => deleteLocationMutation.mutate(location.id)}
                                disabled={deleteLocationMutation.isPending}
                              >
                                <Trash className="h-4 w-4" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-10 text-gray-500">
                    <MapPin className="mx-auto h-10 w-10 mb-2 text-gray-400" />
                    <p>No workplace locations found</p>
                    <p className="text-sm">Add your first location using the form</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}