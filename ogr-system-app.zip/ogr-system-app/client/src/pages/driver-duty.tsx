import { useState, useEffect } from "react";
import DriverLayout from "@/components/layout/driver-layout";
import StartDutyModal from "@/components/start-duty-modal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useGeolocation } from "@/hooks/use-geolocation";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { Loader2, MapPin, AlertTriangle } from "lucide-react";
import DutyCard from "@/components/duty-card";

export default function DriverDuty() {
  const { user } = useAuth();
  const { position, error: geoError, loading: geoLoading, getPosition, isAtWorkLocation } = useGeolocation();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeDuty, setActiveDuty] = useState<any | null>(null);
  const [dutyHistory, setDutyHistory] = useState<any[]>([]);
  
  // Fallback location config if no workplaces are configured
  const fallbackWorkLocation = {
    latitude: "37.7749",
    longitude: "-122.4194",
    radiusInMeters: 500,
    name: "Default Workplace"
  };
  
  // Fetch active workplace location for geofencing
  const { data: workplaceLocation, isLoading: locationLoading } = useQuery({
    queryKey: ["/api/workplace-locations/active"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/workplace-locations/active");
      return await res.json();
    }
  });
  
  // Fetch attendance data
  const { data: attendanceData, isLoading: attendanceLoading, refetch: refetchAttendance } = useQuery({
    queryKey: ["/api/attendance/user", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const res = await apiRequest("GET", `/api/attendance/user/${user.id}`);
      return await res.json();
    }
  });
  
  // Check for active duty and load duty history
  useEffect(() => {
    if (attendanceData && Array.isArray(attendanceData)) {
      // Find attendance record without an end time (active duty)
      const active = attendanceData.find(item => !item.endTime && item.date === format(new Date(), 'yyyy-MM-dd'));
      
      if (active) {
        setActiveDuty(active);
      } else {
        setActiveDuty(null);
      }
      
      // Get recent duty history (completed duties)
      const history = attendanceData
        .filter(item => item.endTime)
        .sort((a, b) => new Date(b.startTime).getTime() - new Date(a.startTime).getTime())
        .slice(0, 5);
      
      setDutyHistory(history);
    }
  }, [attendanceData]);
  
  // Handle showing the start duty modal
  const handleStartDuty = async () => {
    await getPosition();
    setIsModalOpen(true);
  };

  return (
    <DriverLayout>
      <div className="p-4">
        <h1 className="text-xl font-bold mb-4">Duty Management</h1>
        
        {/* Current Duty Status */}
        <DutyCard 
          activeDuty={activeDuty} 
          onDutyEnd={refetchAttendance}
        />
        
        {/* Location Verification Card */}
        {!activeDuty && (
          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="text-lg">Location Verification</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center mb-4">
                <MapPin className="h-10 w-10 text-primary mb-2" />
                <p className="text-center">
                  Your location will be verified before starting duty to ensure you're at the workplace.
                </p>
              </div>
              
              <div className="bg-gray-50 p-4 rounded-md mb-4">
                {geoLoading ? (
                  <div className="flex items-center justify-center py-2">
                    <Loader2 className="h-5 w-5 animate-spin text-primary mr-2" />
                    <span>Checking location...</span>
                  </div>
                ) : geoError ? (
                  <div className="space-y-3">
                    <div className="flex items-center text-red-600">
                      <AlertTriangle className="h-5 w-5 mr-2 flex-shrink-0" />
                      <span className="text-sm">{geoError}</span>
                    </div>
                    
                    {/* Mobile troubleshooting guide */}
                    <div className="p-3 bg-blue-50 rounded border border-blue-200 text-sm">
                      <h4 className="font-medium text-blue-800 mb-2">Troubleshooting location on mobile:</h4>
                      <ul className="list-disc pl-5 space-y-1 text-blue-800 text-xs">
                        <li>Enable location services in your device settings</li>
                        <li>Grant permission when your browser asks for location access</li>
                        <li>If using iOS, go to Settings &gt; Privacy &gt; Location Services</li>
                        <li>On Android, check Settings &gt; Location &gt; App permissions</li>
                        <li>Refresh the page after enabling location access</li>
                      </ul>
                      <Button 
                        onClick={getPosition} 
                        variant="outline"
                        size="sm"
                        className="mt-2 w-full bg-white text-sm"
                      >
                        Try Again
                      </Button>
                    </div>
                  </div>
                ) : position.latitude && position.longitude ? (
                  isAtWorkLocation(
                    parseFloat(workplaceLocation?.latitude || fallbackWorkLocation.latitude), 
                    parseFloat(workplaceLocation?.longitude || fallbackWorkLocation.longitude), 
                    workplaceLocation?.radiusInMeters || fallbackWorkLocation.radiusInMeters
                  ) ? (
                    <div className="flex items-center text-green-600">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span>You are at the workplace</span>
                    </div>
                  ) : (
                    <div className="flex items-center text-yellow-600">
                      <AlertTriangle className="h-5 w-5 mr-2" />
                      <span>You are not at the workplace location</span>
                    </div>
                  )
                ) : (
                  <div className="flex flex-col items-center gap-2">
                    <span>Location not yet verified</span>
                    <Button 
                      onClick={getPosition}
                      variant="outline"
                      size="sm"
                      className="w-full"
                    >
                      Check My Location
                    </Button>
                  </div>
                )}
              </div>
              
              <Button 
                className="w-full"
                onClick={handleStartDuty}
                disabled={attendanceLoading || geoLoading || !!activeDuty}
              >
                {geoLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Checking Location...
                  </>
                ) : "Start Duty"}
              </Button>
            </CardContent>
          </Card>
        )}
        
        {/* Duty History */}
        <Card className="mt-4">
          <CardHeader>
            <CardTitle className="text-lg">Recent Duty History</CardTitle>
          </CardHeader>
          <CardContent>
            {attendanceLoading ? (
              <div className="flex justify-center py-4">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : dutyHistory.length === 0 ? (
              <div className="text-center py-4 text-gray-500">
                No duty history available
              </div>
            ) : (
              <div className="space-y-4">
                {dutyHistory.map((duty) => (
                  <div key={duty.id} className="p-3 border rounded-md">
                    <div className="flex justify-between">
                      <div>
                        <h4 className="font-medium">
                          {format(new Date(duty.date), 'MMMM d, yyyy')}
                        </h4>
                        <p className="text-sm text-gray-600">
                          Vehicle: {duty.vehicleNumber || 'N/A'}
                        </p>
                      </div>
                      <div className="text-right">
                        <span className="block text-sm">
                          {new Date(duty.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - 
                          {new Date(duty.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                        <Badge 
                          className={`mt-1 ${
                            duty.status === 'Present' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {duty.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
        
        {/* Start Duty Modal */}
        <StartDutyModal 
          isOpen={isModalOpen} 
          onClose={() => setIsModalOpen(false)}
          onDutyStart={refetchAttendance}
          isAtWorkplace={position.latitude && position.longitude ? 
            isAtWorkLocation(
              parseFloat(workplaceLocation?.latitude || fallbackWorkLocation.latitude), 
              parseFloat(workplaceLocation?.longitude || fallbackWorkLocation.longitude), 
              workplaceLocation?.radiusInMeters || fallbackWorkLocation.radiusInMeters
            ) : false
          }
        />
      </div>
    </DriverLayout>
  );
}
