import React, { useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import DriverLayout from "@/components/layout/driver-layout";
import { Loader2 } from "lucide-react";

interface NotificationPreferences {
  id: number;
  userId: number;
  shiftReminders: boolean | null;
  scheduleUpdates: boolean | null;
  absenceAlerts: boolean | null;
  pushNotifications: boolean | null;
  emailNotifications: boolean | null;
  updatedAt: Date | null;
}

export default function NotificationSettings() {
  const { user } = useAuth();
  const { toast } = useToast();
  
  const { data: preferences, isLoading } = useQuery<NotificationPreferences>({
    queryKey: [`/api/notification-preferences/${user?.id}`],
    queryFn: () => apiRequest("GET", `/api/notification-preferences/${user?.id}`).then(res => res.json()),
    enabled: !!user
  });
  
  const updatePreferencesMutation = useMutation({
    mutationFn: async (newPreferences: Partial<NotificationPreferences>) => {
      const res = await apiRequest(
        "PATCH", 
        `/api/notification-preferences/${user?.id}`, 
        newPreferences
      );
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/notification-preferences/${user?.id}`] });
      toast({
        title: "Preferences updated",
        description: "Your notification preferences have been saved.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update preferences",
        description: error instanceof Error ? error.message : "Please try again later",
        variant: "destructive",
      });
    }
  });
  
  const handleToggleChange = (field: keyof NotificationPreferences) => (checked: boolean) => {
    if (!user) return;
    
    // Create a complete preferences object if one doesn't exist yet
    if (!preferences && field) {
      // Default values for a new preferences object
      const defaultPreferences = {
        userId: user.id,
        shiftReminders: false,
        scheduleUpdates: false,
        absenceAlerts: false,
        pushNotifications: false,
        emailNotifications: false,
        // Set the current field to the checked value
        [field]: checked
      };
      
      updatePreferencesMutation.mutate(defaultPreferences);
    } else {
      // Just update the specific field
      updatePreferencesMutation.mutate({
        [field]: checked
      });
    }
  };
  
  if (isLoading) {
    return (
      <DriverLayout>
        <div className="flex justify-center items-center min-h-[60vh]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </DriverLayout>
    );
  }
  
  return (
    <DriverLayout>
      <div className="container py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold tracking-tight">Notification Settings</h1>
          <p className="text-muted-foreground mt-2">
            Customize how you receive notifications about your shifts and other important updates.
          </p>
        </div>
        
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Notification Types</CardTitle>
            <CardDescription>
              Choose what types of notifications you want to receive
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between py-2">
              <div>
                <Label htmlFor="shift-reminders" className="font-medium">Shift Reminders</Label>
                <p className="text-sm text-muted-foreground">
                  Get reminded about your upcoming shifts
                </p>
              </div>
              <Switch 
                id="shift-reminders" 
                checked={preferences?.shiftReminders === true} 
                onCheckedChange={handleToggleChange('shiftReminders')} 
                disabled={updatePreferencesMutation.isPending}
              />
            </div>
            
            <Separator />
            
            <div className="flex items-center justify-between py-2">
              <div>
                <Label htmlFor="schedule-updates" className="font-medium">Schedule Updates</Label>
                <p className="text-sm text-muted-foreground">
                  Be notified when your schedule changes
                </p>
              </div>
              <Switch 
                id="schedule-updates" 
                checked={preferences?.scheduleUpdates === true} 
                onCheckedChange={handleToggleChange('scheduleUpdates')} 
                disabled={updatePreferencesMutation.isPending}
              />
            </div>
            
            <Separator />
            
            <div className="flex items-center justify-between py-2">
              <div>
                <Label htmlFor="absence-alerts" className="font-medium">Absence Alerts</Label>
                <p className="text-sm text-muted-foreground">
                  Get warnings if you're at risk of being marked absent
                </p>
              </div>
              <Switch 
                id="absence-alerts" 
                checked={preferences?.absenceAlerts === true} 
                onCheckedChange={handleToggleChange('absenceAlerts')} 
                disabled={updatePreferencesMutation.isPending}
              />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Notification Methods</CardTitle>
            <CardDescription>
              Choose how you want to receive notifications
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between py-2">
              <div>
                <Label htmlFor="push-notifications" className="font-medium">Push Notifications</Label>
                <p className="text-sm text-muted-foreground">
                  Receive notifications in the app and on your device
                </p>
              </div>
              <Switch 
                id="push-notifications" 
                checked={preferences?.pushNotifications === true} 
                onCheckedChange={handleToggleChange('pushNotifications')} 
                disabled={updatePreferencesMutation.isPending}
              />
            </div>
            
            <Separator />
            
            <div className="flex items-center justify-between py-2">
              <div>
                <Label htmlFor="email-notifications" className="font-medium">Email Notifications</Label>
                <p className="text-sm text-muted-foreground">
                  Receive notifications via email
                </p>
              </div>
              <Switch 
                id="email-notifications" 
                checked={preferences?.emailNotifications === true} 
                onCheckedChange={handleToggleChange('emailNotifications')} 
                disabled={updatePreferencesMutation.isPending}
              />
            </div>
          </CardContent>
        </Card>
      </div>
    </DriverLayout>
  );
}