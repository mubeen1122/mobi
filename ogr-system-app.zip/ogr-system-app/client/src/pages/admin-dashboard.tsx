import { useState, useEffect } from "react";
import AdminLayout from "@/components/layout/admin-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { User, Truck, Attendance, Shift, Notification } from "@shared/schema";
import { format } from "date-fns";
import { Loader2, Users, Truck as TruckIcon, CheckCircle, AlertTriangle } from "lucide-react";

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    activeDrivers: 0,
    activeTrucks: 0,
    attendance: 0,
    maintenanceAlerts: 0
  });
  
  // Fetch users
  const { data: users, isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ["/api/users"],
    queryFn: async () => {
      try {
        // This would ideally use a /api/users endpoint in a real app
        // For local storage demo, we'll use individual user fetches
        const res = await apiRequest("GET", `/api/users/1`);
        const adminUser = await res.json();
        
        const res2 = await apiRequest("GET", `/api/users/2`);
        const driverUser = await res2.json();
        
        return [adminUser, driverUser];
      } catch (error) {
        console.error("Error fetching users:", error);
        return [];
      }
    }
  });
  
  // Fetch trucks
  const { data: trucks, isLoading: trucksLoading } = useQuery<Truck[]>({
    queryKey: ["/api/trucks"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/trucks");
      return await res.json();
    }
  });
  
  // Fetch attendance
  const { data: attendance, isLoading: attendanceLoading } = useQuery<Attendance[]>({
    queryKey: ["/api/attendance/date", format(new Date(), 'yyyy-MM-dd')],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/attendance/date/${format(new Date(), 'yyyy-MM-dd')}`);
      return await res.json();
    }
  });
  
  // Calculate stats based on fetched data
  useEffect(() => {
    if (users && trucks && attendance) {
      const driverUsers = users.filter(user => user.role === 'driver');
      const activeTrucks = trucks.filter(truck => truck.status === 'Active');
      const attendanceRate = driverUsers.length > 0 
        ? (attendance.length / driverUsers.length) * 100 
        : 0;
      const maintenanceAlerts = trucks.filter(truck => truck.status === 'In Repair').length;
      
      setStats({
        activeDrivers: driverUsers.length,
        activeTrucks: activeTrucks.length,
        attendance: Math.round(attendanceRate),
        maintenanceAlerts
      });
    }
  }, [users, trucks, attendance]);
  
  // Format driver initials
  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('');
  };
  
  // Calculate duty duration
  const calculateDuration = (startTime: string) => {
    const start = new Date(startTime);
    const now = new Date();
    const diffInHours = (now.getTime() - start.getTime()) / (1000 * 60 * 60);
    const hours = Math.floor(diffInHours);
    const minutes = Math.floor((diffInHours - hours) * 60);
    return `${hours}h ${minutes}m`;
  };
  
  const isLoading = usersLoading || trucksLoading || attendanceLoading;
  
  return (
    <AdminLayout>
      <div className="p-6">
        <header className="mb-6">
          <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
          <p className="text-gray-600">Overview of fleet operations and driver activity</p>
        </header>
        
        {/* Stats Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Active Drivers</p>
                  <h3 className="text-2xl font-bold">{isLoading ? '-' : stats.activeDrivers}</h3>
                </div>
                <div className="bg-primary-100 p-3 rounded-full">
                  <Users className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <span className="text-green-500 text-sm flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                  </svg>
                  8%
                </span>
                <span className="text-gray-500 text-sm ml-2">from last week</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Active Trucks</p>
                  <h3 className="text-2xl font-bold">{isLoading ? '-' : stats.activeTrucks}</h3>
                </div>
                <div className="bg-green-100 p-3 rounded-full">
                  <TruckIcon className="h-6 w-6 text-green-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <span className="text-red-500 text-sm flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                  </svg>
                  3%
                </span>
                <span className="text-gray-500 text-sm ml-2">from last week</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Current Attendance</p>
                  <h3 className="text-2xl font-bold">{isLoading ? '-' : `${stats.attendance}%`}</h3>
                </div>
                <div className="bg-blue-100 p-3 rounded-full">
                  <CheckCircle className="h-6 w-6 text-blue-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <span className="text-green-500 text-sm flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                  </svg>
                  5%
                </span>
                <span className="text-gray-500 text-sm ml-2">from last month</span>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500">Maintenance Alerts</p>
                  <h3 className="text-2xl font-bold">{isLoading ? '-' : stats.maintenanceAlerts}</h3>
                </div>
                <div className="bg-yellow-100 p-3 rounded-full">
                  <AlertTriangle className="h-6 w-6 text-yellow-600" />
                </div>
              </div>
              <div className="mt-4 flex items-center">
                <span className="text-red-500 text-sm flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                  </svg>
                  2
                </span>
                <span className="text-gray-500 text-sm ml-2">from yesterday</span>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Active Duties */}
        <Card className="mb-6">
          <CardHeader className="pb-2">
            <CardTitle>Current Active Duties</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Driver</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Truck</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Start Time</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Duration</th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {isLoading ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-4 text-center">
                        <Loader2 className="h-6 w-6 animate-spin text-primary mx-auto" />
                      </td>
                    </tr>
                  ) : !attendance || attendance.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-4 text-center text-gray-500">
                        No active duties at the moment
                      </td>
                    </tr>
                  ) : (
                    attendance.filter(a => !a.endTime).map((duty) => {
                      const driver = users?.find(u => u.id === duty.userId);
                      
                      return (
                        <tr key={duty.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="h-10 w-10 flex-shrink-0">
                                <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 font-medium">
                                  {driver ? getInitials(driver.name) : '??'}
                                </div>
                              </div>
                              <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900">{driver?.name || 'Unknown'}</div>
                                <div className="text-sm text-gray-500">{driver?.role || 'Driver'}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">{duty.vehicleNumber || 'N/A'}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">
                              {format(new Date(duty.startTime), 'h:mm a')}
                            </div>
                            <div className="text-sm text-gray-500">
                              {format(new Date(duty.startTime), 'MMM d, yyyy')}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-900">{calculateDuration(duty.startTime)}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                              Active
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <Button variant="link" className="text-primary-600 hover:text-primary-900">
                              Details
                            </Button>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
        
        {/* Recent Notifications and Truck Status */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader className="pb-0 pt-6 px-6 flex flex-row items-center justify-between">
              <CardTitle className="text-base font-semibold">Recent Notifications</CardTitle>
              <Button variant="ghost" size="sm" className="h-8 text-xs">View All</Button>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-3">
                <div className="p-3 border-l-4 border-primary bg-primary-50 rounded-sm">
                  <div className="flex justify-between">
                    <h4 className="font-medium">Shift Request</h4>
                    <span className="text-xs text-gray-500">2h ago</span>
                  </div>
                  <p className="text-sm text-gray-600">John Doe requested a shift swap for June 5th</p>
                </div>
                
                <div className="p-3 border-l-4 border-yellow-500 bg-yellow-50 rounded-sm">
                  <div className="flex justify-between">
                    <h4 className="font-medium">Maintenance Alert</h4>
                    <span className="text-xs text-gray-500">5h ago</span>
                  </div>
                  <p className="text-sm text-gray-600">Truck T-9101 is due for scheduled maintenance</p>
                </div>
                
                <div className="p-3 border-l-4 border-red-500 bg-red-50 rounded-sm">
                  <div className="flex justify-between">
                    <h4 className="font-medium">Absence Report</h4>
                    <span className="text-xs text-gray-500">12h ago</span>
                  </div>
                  <p className="text-sm text-gray-600">Jason Miller missed his scheduled shift on June 3rd</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-0 pt-6 px-6">
              <CardTitle className="text-base font-semibold">Truck Status Overview</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <div className="w-full h-64 flex items-center justify-center bg-gray-50 rounded">
                {trucksLoading ? (
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                ) : (
                  <div className="text-center py-6">
                    <div className="inline-flex items-center justify-center mb-4 flex-wrap gap-4">
                      <div className="flex items-center">
                        <div className="w-4 h-4 rounded-full bg-green-500 mr-2"></div>
                        <span>Active ({stats.activeTrucks})</span>
                      </div>
                      
                      <div className="flex items-center">
                        <div className="w-4 h-4 rounded-full bg-yellow-500 mr-2"></div>
                        <span>In Repair ({stats.maintenanceAlerts})</span>
                      </div>
                      
                      <div className="flex items-center">
                        <div className="w-4 h-4 rounded-full bg-gray-300 mr-2"></div>
                        <span>Decommissioned (0)</span>
                      </div>
                    </div>
                    
                    {/* Simple chart representation */}
                    <div className="flex h-24 items-end justify-center space-x-6">
                      <div 
                        className="w-16 bg-green-500 rounded-t" 
                        style={{ height: `${(stats.activeTrucks / (stats.activeTrucks + stats.maintenanceAlerts + 1)) * 100}%` }}
                      ></div>
                      <div 
                        className="w-16 bg-yellow-500 rounded-t" 
                        style={{ height: `${(stats.maintenanceAlerts / (stats.activeTrucks + stats.maintenanceAlerts + 1)) * 100}%` }}
                      ></div>
                      <div 
                        className="w-16 bg-gray-300 rounded-t" 
                        style={{ height: '10%' }}
                      ></div>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </AdminLayout>
  );
}
