import { useState, useEffect } from "react";
import AdminLayout from "@/components/layout/admin-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { type Attendance, type User } from "@shared/schema";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format, parseISO, isToday, isSameDay } from "date-fns";
import { Loader2, Search, Calendar as CalendarIcon, Edit, Clock, AlertTriangle } from "lucide-react";
import { differenceInHours, differenceInMinutes } from "date-fns";
import { checkAllDrivers, LATE_THRESHOLD_MINUTES } from "@/services/attendance-checker";

export default function AdminAttendance() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editingAttendance, setEditingAttendance] = useState<Attendance | null>(null);
  const [isRunningAutoCheck, setIsRunningAutoCheck] = useState(false);
  const [showAutoCheckInfo, setShowAutoCheckInfo] = useState(false);

  // Format date for API request
  const formattedDate = format(selectedDate, "yyyy-MM-dd");

  // Fetch attendance records for selected date
  const { data: attendanceRecords, isLoading: attendanceLoading } = useQuery<Attendance[]>({
    queryKey: ["/api/attendance/date", formattedDate],
    queryFn: async () => {
      const res = await apiRequest("GET", `/api/attendance/date/${formattedDate}`);
      return await res.json();
    },
  });

  // Fetch all users
  const { data: users } = useQuery<User[]>({
    queryKey: ["/api/users"],
    queryFn: async () => {
      try {
        // For demo purposes, we'll return a simulated users dataset
        const res1 = await apiRequest("GET", `/api/users/1`);
        const admin = await res1.json();
        
        const res2 = await apiRequest("GET", `/api/users/2`);
        const driver = await res2.json();
        
        return [admin, driver];
      } catch (error) {
        console.error("Error fetching users:", error);
        return [];
      }
    }
  });

  // Update attendance record mutation
  const updateAttendanceMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Attendance> }) => {
      const res = await apiRequest("PATCH", `/api/attendance/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/attendance/date", formattedDate] });
      setIsEditDialogOpen(false);
      setEditingAttendance(null);
      toast({
        title: "Success",
        description: "Attendance record has been updated.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle marking a user as absent
  const handleMarkAbsent = async (userId: number) => {
    try {
      // Create an attendance record with status "Absent"
      await apiRequest("POST", "/api/attendance", {
        userId,
        startTime: new Date().toISOString(),
        endTime: new Date().toISOString(), // Same time to indicate no work done
        status: "Absent",
        date: formattedDate,
      });

      queryClient.invalidateQueries({ queryKey: ["/api/attendance/date", formattedDate] });
      
      toast({
        title: "Success",
        description: "Worker has been marked as absent.",
      });
    } catch (error) {
      console.error("Error marking worker as absent:", error);
      toast({
        title: "Error",
        description: "Failed to mark worker as absent.",
        variant: "destructive",
      });
    }
  };

  // Edit attendance record
  const handleEditRecord = (record: Attendance) => {
    setEditingAttendance(record);
    setIsEditDialogOpen(true);
  };

  // Handle changing attendance status
  const handleChangeStatus = (status: string) => {
    if (!editingAttendance) return;
    
    updateAttendanceMutation.mutate({
      id: editingAttendance.id,
      data: { status }
    });
  };

  // Filter records by search term
  const filteredRecords = attendanceRecords
    ?.filter((record) => {
      const user = users?.find(u => u.id === record.userId);
      if (!user) return false;
      
      return (
        user.name.toLowerCase().includes(search.toLowerCase()) ||
        user.username.toLowerCase().includes(search.toLowerCase()) ||
        (record.vehicleNumber && record.vehicleNumber.toLowerCase().includes(search.toLowerCase()))
      );
    }) || [];

  // Calculate work duration
  const calculateDuration = (startTime: string, endTime: string | null) => {
    if (!endTime) return "In progress";
    
    const start = parseISO(startTime);
    const end = parseISO(endTime);
    
    const hoursDiff = differenceInHours(end, start);
    const minutesDiff = differenceInMinutes(end, start) % 60;
    
    return `${hoursDiff}h ${minutesDiff}m`;
  };

  // Get user name
  const getUserName = (userId: number) => {
    const user = users?.find(u => u.id === userId);
    return user ? user.name : "Unknown";
  };

  return (
    <AdminLayout>
      <div className="p-6">
        <header className="mb-6">
          <h1 className="text-2xl font-bold text-gray-800">Attendance Management</h1>
          <p className="text-gray-600">Track and manage driver attendance</p>
        </header>

        {/* Date selector and search */}
        <div className="mb-6 flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
          <div>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant={"outline"}
                  className="w-[240px] justify-start text-left font-normal"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {format(selectedDate, "PPP")}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => date && setSelectedDate(date)}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search by name or vehicle..."
              className="pl-10"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          {isToday(selectedDate) && (
            <div>
              <Button
                onClick={async () => {
                  try {
                    setIsRunningAutoCheck(true);
                    const absenceCount = await checkAllDrivers();
                    
                    if (absenceCount > 0) {
                      toast({
                        title: "Auto-check completed",
                        description: `${absenceCount} driver${absenceCount !== 1 ? 's' : ''} automatically marked as absent.`
                      });
                    } else {
                      toast({
                        title: "Auto-check completed",
                        description: "No drivers were marked as absent."
                      });
                    }
                    
                    // Refresh attendance data
                    queryClient.invalidateQueries({ queryKey: ["/api/attendance/date", formattedDate] });
                  } catch (error) {
                    console.error("Error running auto-check:", error);
                    toast({
                      title: "Error",
                      description: "Failed to run automatic absence check.",
                      variant: "destructive"
                    });
                  } finally {
                    setIsRunningAutoCheck(false);
                  }
                }}
                disabled={isRunningAutoCheck}
                className="relative"
              >
                {isRunningAutoCheck ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Checking...
                  </>
                ) : (
                  <>
                    <Clock className="mr-2 h-4 w-4" />
                    Auto-check absences
                  </>
                )}
              </Button>
              
              <Button 
                variant="ghost" 
                size="icon"
                className="ml-2"
                onClick={() => setShowAutoCheckInfo(!showAutoCheckInfo)}
              >
                <AlertTriangle className="h-4 w-4" />
              </Button>
              
              {showAutoCheckInfo && (
                <div className="mt-2 p-3 text-sm bg-amber-50 border border-amber-200 rounded-md">
                  <p>Drivers who don't log in or start duty within {LATE_THRESHOLD_MINUTES} minutes 
                  of their scheduled shift will be automatically marked as absent.</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Attendance Records */}
        <Card>
          <CardHeader>
            <CardTitle>
              Attendance Records for {format(selectedDate, "MMMM d, yyyy")}
              {isToday(selectedDate) && " (Today)"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {attendanceLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredRecords.length === 0 ? (
              <div className="p-6 text-center">
                <p className="text-gray-500">No attendance records found for this date.</p>
                <div className="mt-4">
                  {/* Show absent buttons for drivers without attendance */}
                  {users?.filter(user => 
                    user.role === 'driver' && 
                    !attendanceRecords?.some(record => record.userId === user.id)
                  ).map(driver => (
                    <div key={driver.id} className="flex items-center justify-between p-2 border-t">
                      <div>
                        <p className="font-medium">{driver.name}</p>
                        <p className="text-sm text-gray-500">No record for today</p>
                      </div>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => handleMarkAbsent(driver.id)}
                      >
                        Mark as Absent
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Driver
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Vehicle
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Start Time
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        End Time
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Duration
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredRecords.map((record) => (
                      <tr key={record.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex items-center">
                            <div className="h-10 w-10 flex-shrink-0">
                              <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-600 font-medium">
                                {getUserName(record.userId).split(' ').map(n => n[0]).join('')}
                              </div>
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">
                                {getUserName(record.userId)}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">
                            {record.vehicleNumber || "N/A"}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">
                            {record.startTime ? format(parseISO(record.startTime), "h:mm a") : "N/A"}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">
                            {record.endTime ? format(parseISO(record.endTime), "h:mm a") : "Active"}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">
                            {calculateDuration(record.startTime, record.endTime)}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Badge
                            className={`${
                              record.status === "Present"
                                ? "bg-green-100 text-green-800"
                                : "bg-red-100 text-red-800"
                            }`}
                          >
                            {record.status}
                          </Badge>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-primary-600 hover:text-primary-900"
                            onClick={() => handleEditRecord(record)}
                          >
                            <Edit className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Edit Attendance Dialog */}
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Edit Attendance Record</DialogTitle>
            </DialogHeader>
            
            {editingAttendance && (
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium">Driver</p>
                  <p>{getUserName(editingAttendance.userId)}</p>
                </div>
                
                <div>
                  <p className="text-sm font-medium">Date</p>
                  <p>{format(parseISO(editingAttendance.startTime), "MMMM d, yyyy")}</p>
                </div>
                
                <div>
                  <p className="text-sm font-medium">Vehicle</p>
                  <p>{editingAttendance.vehicleNumber || "None"}</p>
                </div>
                
                <div>
                  <p className="text-sm font-medium">Time Period</p>
                  <p>
                    {format(parseISO(editingAttendance.startTime), "h:mm a")} - 
                    {editingAttendance.endTime
                      ? format(parseISO(editingAttendance.endTime), " h:mm a")
                      : " In progress"}
                  </p>
                </div>
                
                <div>
                  <p className="text-sm font-medium">Status</p>
                  <div className="flex space-x-2 mt-1">
                    <Button
                      size="sm"
                      variant={editingAttendance.status === "Present" ? "default" : "outline"}
                      onClick={() => handleChangeStatus("Present")}
                      disabled={updateAttendanceMutation.isPending}
                    >
                      Present
                    </Button>
                    <Button
                      size="sm"
                      variant={editingAttendance.status === "Absent" ? "default" : "outline"}
                      onClick={() => handleChangeStatus("Absent")}
                      disabled={updateAttendanceMutation.isPending}
                    >
                      Absent
                    </Button>
                  </div>
                </div>
              </div>
            )}
            
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setIsEditDialogOpen(false)}
                disabled={updateAttendanceMutation.isPending}
              >
                Cancel
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
