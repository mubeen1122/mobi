import { useState } from "react";
import AdminLayout from "@/components/layout/admin-layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { type Truck, type User, insertTruckSchema } from "@shared/schema";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, Search, Plus } from "lucide-react";

// Extend the schema with validation
const truckFormSchema = insertTruckSchema.extend({});

type TruckFormValues = z.infer<typeof truckFormSchema>;

export default function AdminTrucks() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTruck, setEditingTruck] = useState<Truck | null>(null);
  const [statusFilter, setStatusFilter] = useState("all");

  // Fetch all trucks
  const { data: trucks, isLoading: trucksLoading } = useQuery<Truck[]>({
    queryKey: ["/api/trucks"],
    queryFn: async () => {
      const res = await apiRequest("GET", "/api/trucks");
      return await res.json();
    },
  });

  // Fetch users for driver selection
  const { data: users } = useQuery<User[]>({
    queryKey: ["/api/users"],
    queryFn: async () => {
      try {
        // For demo, we'll simulate by fetching user 1 and 2
        const res1 = await apiRequest("GET", `/api/users/1`);
        const admin = await res1.json();
        
        const res2 = await apiRequest("GET", `/api/users/2`);
        const driver = await res2.json();
        
        return [admin, driver];
      } catch (error) {
        console.error("Error fetching users:", error);
        return [];
      }
    }
  });

  // Create truck mutation
  const createTruckMutation = useMutation({
    mutationFn: async (truckData: TruckFormValues) => {
      const res = await apiRequest("POST", "/api/trucks", truckData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/trucks"] });
      setIsDialogOpen(false);
      toast({
        title: "Success",
        description: "Truck has been added successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update truck mutation
  const updateTruckMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<Truck> }) => {
      const res = await apiRequest("PATCH", `/api/trucks/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/trucks"] });
      setIsDialogOpen(false);
      setEditingTruck(null);
      toast({
        title: "Success",
        description: "Truck has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Form for creating/editing trucks
  const form = useForm<TruckFormValues>({
    resolver: zodResolver(truckFormSchema),
    defaultValues: {
      truckNumber: "",
      status: "Active",
    },
  });

  // Reset and open form for creating a new truck
  const handleAddTruck = () => {
    form.reset({
      truckNumber: "",
      status: "Active",
      assignedTo: undefined,
    });
    setEditingTruck(null);
    setIsDialogOpen(true);
  };

  // Open form for editing a truck
  const handleEditTruck = (truck: Truck) => {
    form.reset({
      truckNumber: truck.truckNumber,
      status: truck.status,
      assignedTo: truck.assignedTo,
    });
    setEditingTruck(truck);
    setIsDialogOpen(true);
  };

  // Handle form submission
  const onSubmit = (data: TruckFormValues) => {
    if (editingTruck) {
      updateTruckMutation.mutate({ id: editingTruck.id, data });
    } else {
      createTruckMutation.mutate(data);
    }
  };

  // Filter trucks by search and status
  const filteredTrucks = trucks
    ?.filter((truck) => {
      // Filter by status
      if (statusFilter !== "all" && truck.status !== statusFilter) {
        return false;
      }
      
      // Filter by search term
      return truck.truckNumber.toLowerCase().includes(search.toLowerCase());
    })
    .sort((a, b) => a.truckNumber.localeCompare(b.truckNumber)) || [];

  // Helper to get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Active":
        return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case "In Repair":
        return <Badge className="bg-yellow-100 text-yellow-800">In Repair</Badge>;
      case "Decommissioned":
        return <Badge variant="outline">Decommissioned</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  // Get driver name
  const getDriverName = (driverId?: number) => {
    if (!driverId) return "Unassigned";
    const driver = users?.find(user => user.id === driverId);
    return driver ? driver.name : "Unknown";
  };

  return (
    <AdminLayout>
      <div className="p-6">
        <header className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Truck Management</h1>
            <p className="text-gray-600">Manage your fleet of vehicles</p>
          </div>
          <Button 
            className="mt-4 sm:mt-0"
            onClick={handleAddTruck}
          >
            <Plus className="h-4 w-4 mr-2" />
            Add New Truck
          </Button>
        </header>

        {/* Search and Filter */}
        <div className="mb-6 flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search trucks..."
              className="pl-10"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Select
            value={statusFilter}
            onValueChange={setStatusFilter}
          >
            <SelectTrigger className="w-full sm:w-[180px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="Active">Active</SelectItem>
              <SelectItem value="In Repair">In Repair</SelectItem>
              <SelectItem value="Decommissioned">Decommissioned</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Trucks List */}
        <Card>
          <CardHeader>
            <CardTitle>Trucks</CardTitle>
          </CardHeader>
          <CardContent>
            {trucksLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredTrucks.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No trucks found matching your search criteria
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Truck Number
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Status
                      </th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Assigned To
                      </th>
                      <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredTrucks.map((truck) => (
                      <tr key={truck.id}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">
                            {truck.truckNumber}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {getStatusBadge(truck.status)}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="text-sm text-gray-900">
                            {getDriverName(truck.assignedTo)}
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditTruck(truck)}
                            className="text-primary-600 hover:text-primary-900"
                          >
                            Edit
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Add/Edit Truck Dialog */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>
                {editingTruck ? 'Edit Truck' : 'Add New Truck'}
              </DialogTitle>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="truckNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Truck Number</FormLabel>
                      <FormControl>
                        <Input 
                          {...field} 
                          placeholder="T-1234"
                          disabled={!!editingTruck} // Can't change truck number when editing
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Active">Active</SelectItem>
                          <SelectItem value="In Repair">In Repair</SelectItem>
                          <SelectItem value="Decommissioned">Decommissioned</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="assignedTo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Assigned Driver</FormLabel>
                      <Select 
                        onValueChange={(value) => {
                          if (value === "unassigned") {
                            field.onChange(undefined);
                          } else {
                            field.onChange(Number(value));
                          }
                        }} 
                        value={field.value?.toString() || "unassigned"}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a driver (optional)" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="unassigned">Unassigned</SelectItem>
                          {users?.filter(user => user.role === 'driver').map((driver) => (
                            <SelectItem key={driver.id} value={driver.id.toString()}>
                              {driver.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter className="mt-6">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsDialogOpen(false)}
                    disabled={createTruckMutation.isPending || updateTruckMutation.isPending}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={createTruckMutation.isPending || updateTruckMutation.isPending}
                  >
                    {(createTruckMutation.isPending || updateTruckMutation.isPending) ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : editingTruck ? 'Update Truck' : 'Add Truck'}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </AdminLayout>
  );
}
