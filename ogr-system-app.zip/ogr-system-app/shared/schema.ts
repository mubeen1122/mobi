import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  role: text("role").notNull().default("driver"),
  email: text("email"),
  assignedTruck: text("assigned_truck"),
});

// Trucks table
export const trucks = pgTable("trucks", {
  id: serial("id").primaryKey(),
  truckNumber: text("truck_number").notNull().unique(),
  status: text("status").notNull().default("Active"), // Active, In Repair, Decommissioned
  assignedTo: integer("assigned_to").references(() => users.id),
});

// Shifts table
export const shifts = pgTable("shifts", {
  id: serial("id").primaryKey(),
  shiftDate: text("shift_date").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  assignedDriver: integer("assigned_driver").references(() => users.id),
  assignedTruck: text("assigned_truck"), // Store the truck ID as a string
  shiftStatus: text("shift_status").notNull().default("Scheduled"), // Scheduled, Accepted, Completed, Absent
});

// Attendance table
export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time"),
  status: text("status").notNull().default("Present"), // Present, Absent
  vehicleNumber: text("vehicle_number"),
  date: text("date").notNull(),
});

// Notifications table
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  sentTo: integer("sent_to").references(() => users.id),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  read: boolean("read").default(false),
});

// Workplace location settings for geofencing
export const workplaceLocations = pgTable("workplace_locations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  latitude: text("latitude").notNull(),
  longitude: text("longitude").notNull(),
  radiusInMeters: integer("radius_in_meters").notNull().default(100),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Notification preferences table
export const notificationPreferences = pgTable("notification_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  shiftReminders: boolean("shift_reminders").default(true),
  scheduleUpdates: boolean("schedule_updates").default(true),
  absenceAlerts: boolean("absence_alerts").default(true),
  pushNotifications: boolean("push_notifications").default(true),
  emailNotifications: boolean("email_notifications").default(false),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Define relations
export const usersRelations = relations(users, ({ many, one }) => ({
  trucks: many(trucks, { relationName: "user_trucks" }),
  shifts: many(shifts, { relationName: "user_shifts" }),
  attendances: many(attendance, { relationName: "user_attendances" }),
  notifications: many(notifications, { relationName: "user_notifications" }),
  notificationPreferences: many(notificationPreferences),
}));

export const trucksRelations = relations(trucks, ({ one }) => ({
  assignedUser: one(users, {
    fields: [trucks.assignedTo],
    references: [users.id],
    relationName: "user_trucks"
  }),
}));

export const shiftsRelations = relations(shifts, ({ one }) => ({
  driver: one(users, {
    fields: [shifts.assignedDriver],
    references: [users.id],
    relationName: "user_shifts"
  }),
}));

export const attendanceRelations = relations(attendance, ({ one }) => ({
  user: one(users, {
    fields: [attendance.userId],
    references: [users.id],
    relationName: "user_attendances"
  }),
}));

export const notificationsRelations = relations(notifications, ({ one }) => ({
  user: one(users, {
    fields: [notifications.sentTo],
    references: [users.id],
    relationName: "user_notifications"
  }),
}));

export const notificationPreferencesRelations = relations(notificationPreferences, ({ one }) => ({
  user: one(users, {
    fields: [notificationPreferences.userId],
    references: [users.id],
    relationName: "user_notification_preferences"
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  role: true,
  email: true,
  assignedTruck: true,
});

export const insertTruckSchema = createInsertSchema(trucks).pick({
  truckNumber: true,
  status: true,
  assignedTo: true,
});

export const insertShiftSchema = createInsertSchema(shifts).pick({
  shiftDate: true,
  startTime: true,
  endTime: true,
  assignedDriver: true,
  assignedTruck: true,
  shiftStatus: true,
});

export const insertAttendanceSchema = createInsertSchema(attendance)
  .pick({
    userId: true,
    status: true,
    vehicleNumber: true,
    date: true,
  })
  .extend({
    // Accept ISO string for startTime and parse it to a Date
    startTime: z.string().transform((val) => new Date(val)),
    // Accept ISO string for endTime and parse it to a Date, or null
    endTime: z.string().nullable().optional().transform((val) => val ? new Date(val) : null),
  });

export const insertNotificationSchema = createInsertSchema(notifications).pick({
  title: true,
  body: true,
  sentTo: true,
  timestamp: true,
  read: true,
});

export const insertWorkplaceLocationSchema = createInsertSchema(workplaceLocations).pick({
  name: true,
  latitude: true,
  longitude: true,
  radiusInMeters: true,
  isActive: true,
});

export const insertNotificationPreferencesSchema = createInsertSchema(notificationPreferences).pick({
  userId: true,
  shiftReminders: true,
  scheduleUpdates: true,
  absenceAlerts: true,
  pushNotifications: true,
  emailNotifications: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertTruck = z.infer<typeof insertTruckSchema>;
export type Truck = typeof trucks.$inferSelect;

export type InsertShift = z.infer<typeof insertShiftSchema>;
export type Shift = typeof shifts.$inferSelect;

export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Attendance = typeof attendance.$inferSelect;

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

export type InsertWorkplaceLocation = z.infer<typeof insertWorkplaceLocationSchema>;
export type WorkplaceLocation = typeof workplaceLocations.$inferSelect;

export type InsertNotificationPreferences = z.infer<typeof insertNotificationPreferencesSchema>;
export type NotificationPreferences = typeof notificationPreferences.$inferSelect;
